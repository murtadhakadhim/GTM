# Security Report

## Controls implemented

- RLS enabled for gym data tables. Only provisioned admin/coach roles receive staff policies.
- Admins manage all records. Coaches can view courses/training days and manage exercises/media, but cannot read trainees, assignments, or subscriptions through the Data API.
- Members read only their `auth_user_id` row, its single course assignment, that course's days/exercises, their subscriptions, and matching private media objects.
- Four-digit PIN provisioning and login are server-side Edge Functions. The PIN is never stored in Postgres; a private HMAC pepper derives the Auth password, and login attempts are throttled with HMAC-hashed phone/IP keys (5 per phone and 30 per IP per 10 minutes).
- A unique partial index prevents one Auth UID linking to two trainee records. Phone duplicates are handled by refusing an ambiguous link.
- Supabase secret/service keys are not used in browser code or `.env.example`.
- Private Storage signed URLs are short-lived. Member signed URLs are requested only when the corresponding image/video is opened.
- File type, video 200 MiB and image 10 MiB limits are checked on client and enforced by bucket configuration.
- No SMS/OTP is used. Optional Supabase CAPTCHA/Turnstile can provide an additional login check.

## Limits / follow-up

- Course rows still store `coach_name` as text, not a coach Auth relationship. Coaches can manage exercises across the gym's courses; per-course coach isolation would require a course-to-staff foreign key and corresponding dashboard assignment UI.
- The first migration in a fresh setup predates strict role policies; apply migrations 001, 002, and 003 in order without enabling sign-ins between them.
- Live Supabase policies/functions/storage were not applied or audited against a remote project in this workspace.
- A four-digit PIN is low entropy; rate limiting and admin-managed resets reduce risk but do not make it a strong password. There is no self-service PIN recovery.
- Dependency vulnerability scanning, SQL policy execution tests, and PIN abuse tests have not run here.
