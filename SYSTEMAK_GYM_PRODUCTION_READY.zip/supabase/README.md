# Supabase Project Guide

Use the root `SUPABASE_SETUP.md` as the full setup procedure. Apply `migrations/001_gym.sql`, `002_member_app_security.sql`, `003_separate_exercise_media_buckets.sql`, and `004_training_library_coaches_audit.sql` in numerical order before enabling users. Migration 004 is additive and preserves existing workout rows and media. The empty `seed.sql` intentionally creates no fake gym data.

Link the CLI to the intended Supabase project before `supabase db push` or `supabase functions deploy`. Deploy `member-pin-login`, `set-member-pin`, and `invite-coach`. Local files do not prove that migrations/functions were applied remotely; confirm them in the intended Supabase project.
