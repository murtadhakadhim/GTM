import { createClient } from 'npm:@supabase/supabase-js@2';

const cors = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
};

function normalizePhone(value: unknown): string {
  let digits = String(value ?? '').replace(/\D/g, '');
  if (digits.startsWith('00964')) digits = digits.slice(2);
  if (digits.startsWith('964')) return `+${digits}`;
  if (digits.startsWith('0')) return `+964${digits.slice(1)}`;
  if (digits.startsWith('7')) return `+964${digits}`;
  return digits ? `+${digits}` : '';
}

function keyFromEnv(legacyName: string, mapName: string): string {
  const legacy = Deno.env.get(legacyName);
  if (legacy) return legacy;
  const keys = JSON.parse(Deno.env.get(mapName) || '{}');
  if (typeof keys.default === 'string') return keys.default;
  throw new Error(`${mapName} is not configured`);
}

async function privateHash(value: string, secret: string): Promise<string> {
  const key = await crypto.subtle.importKey('raw', new TextEncoder().encode(secret), { name: 'HMAC', hash: 'SHA-256' }, false, ['sign']);
  const signed = await crypto.subtle.sign('HMAC', key, new TextEncoder().encode(value));
  return [...new Uint8Array(signed)].map((byte) => byte.toString(16).padStart(2, '0')).join('');
}

async function hmacHex(message: string, pepper: string): Promise<string> {
  const key = await crypto.subtle.importKey('raw', new TextEncoder().encode(pepper), { name: 'HMAC', hash: 'SHA-256' }, false, ['sign']);
  const signed = await crypto.subtle.sign('HMAC', key, new TextEncoder().encode(message));
  return [...new Uint8Array(signed)].map((byte) => byte.toString(16).padStart(2, '0')).join('');
}

async function memberAuthEmail(phone: string, pepper: string): Promise<string> {
  const identity = await hmacHex(`systemak-member-auth-id-v1:${phone}`, pepper);
  return `member-${identity}@members.systemak.invalid`;
}

async function deriveAuthPassword(phone: string, pin: string, pepper: string): Promise<string> {
  return hmacHex(`systemak-member-pin-v1:${phone}:${pin}`, pepper);
}

Deno.serve(async (request) => {
  if (request.method === 'OPTIONS') return new Response('ok', { headers: cors });
  if (request.method !== 'POST') return Response.json({ error: 'Method not allowed' }, { status: 405, headers: cors });
  try {
    const body = await request.json();
    const phone = normalizePhone(body.phone);
    const pin = String(body.pin ?? '');
    if (phone.length < 11 || phone.length > 16 || !/^\d{4}$/.test(pin)) {
      return Response.json({ error: 'Invalid credentials' }, { status: 401, headers: cors });
    }

    const url = Deno.env.get('SUPABASE_URL')!;
    const secret = keyFromEnv('SUPABASE_SERVICE_ROLE_KEY', 'SUPABASE_SECRET_KEYS');
    const publishable = keyFromEnv('SUPABASE_ANON_KEY', 'SUPABASE_PUBLISHABLE_KEYS');
    const db = createClient(url, secret, { auth: { persistSession: false, autoRefreshToken: false } });
    const ip = request.headers.get('cf-connecting-ip') || request.headers.get('x-real-ip') || request.headers.get('x-forwarded-for')?.split(',')[0]?.trim() || 'unknown';
    const [phoneKey, ipKey] = await Promise.all([privateHash(`phone:${phone}`, secret), privateHash(`ip:${ip}`, secret)]);
    const [phoneAllowed, ipAllowed] = await Promise.all([
      db.rpc('consume_member_phone_rate_limit', { p_key_hash: phoneKey, p_max_hits: 5, p_window_seconds: 600 }),
      db.rpc('consume_member_phone_rate_limit', { p_key_hash: ipKey, p_max_hits: 30, p_window_seconds: 600 }),
    ]);
    if (phoneAllowed.error || ipAllowed.error) throw phoneAllowed.error || ipAllowed.error;
    if (!phoneAllowed.data || !ipAllowed.data) return Response.json({ error: 'Too many attempts' }, { status: 429, headers: cors });

    const { data: matches, error: lookupError } = await db.from('trainees').select('id,auth_user_id').eq('phone_e164', phone).limit(2);
    if (lookupError) throw lookupError;
    if (!matches.length) return Response.json({ error: 'Phone not registered' }, { status: 404, headers: cors });
    if (matches.length !== 1) return Response.json({ error: 'Phone requires admin review' }, { status: 409, headers: cors });
    if (!matches[0].auth_user_id) return Response.json({ error: 'PIN not enabled' }, { status: 409, headers: cors });

    const pepper = Deno.env.get('MEMBER_PIN_PEPPER');
    if (!pepper || pepper.length < 32) throw new Error('MEMBER_PIN_PEPPER must be configured with at least 32 characters');
    const auth = createClient(url, publishable, { auth: { persistSession: false, autoRefreshToken: false } });
    const email = await memberAuthEmail(phone, pepper);
    const password = await deriveAuthPassword(phone, pin, pepper);
    const { data: authData, error: authError } = await auth.auth.signInWithPassword({
      email,
      password,
      options: body.captchaToken ? { captchaToken: String(body.captchaToken) } : undefined,
    });
    if (authError || !authData.session) {
      const captcha = authError?.code === 'captcha_failed';
      return Response.json({ error: captcha ? 'Captcha failed' : 'Invalid credentials' }, { status: captcha ? 400 : 401, headers: cors });
    }
    return Response.json({ session: authData.session }, { headers: cors });
  } catch (error) {
    console.error('member-pin-login failed', error);
    return Response.json({ error: 'Unable to sign in' }, { status: 500, headers: cors });
  }
});
