import { createClient } from 'npm:@supabase/supabase-js@2';

const cors = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
};

function normalizePhone(value: unknown): string {
  let digits = String(value ?? '').replace(/\D/g, '');
  if (digits.startsWith('00964')) digits = digits.slice(2);
  if (digits.startsWith('964')) return `+${digits}`;
  if (digits.startsWith('0')) return `+964${digits.slice(1)}`;
  if (digits.startsWith('7')) return `+964${digits}`;
  return digits ? `+${digits}` : '';
}

function keyFromEnv(legacyName: string, mapName: string): string {
  const legacy = Deno.env.get(legacyName);
  if (legacy) return legacy;
  const keys = JSON.parse(Deno.env.get(mapName) || '{}');
  if (typeof keys.default === 'string') return keys.default;
  throw new Error(`${mapName} is not configured`);
}

async function hmacHex(message: string, pepper: string): Promise<string> {
  const key = await crypto.subtle.importKey('raw', new TextEncoder().encode(pepper), { name: 'HMAC', hash: 'SHA-256' }, false, ['sign']);
  const signed = await crypto.subtle.sign('HMAC', key, new TextEncoder().encode(message));
  return [...new Uint8Array(signed)].map((byte) => byte.toString(16).padStart(2, '0')).join('');
}

async function memberAuthEmail(phone: string, pepper: string): Promise<string> {
  const identity = await hmacHex(`systemak-member-auth-id-v1:${phone}`, pepper);
  return `member-${identity}@members.systemak.invalid`;
}

async function deriveAuthPassword(phone: string, pin: string, pepper: string): Promise<string> {
  return hmacHex(`systemak-member-pin-v1:${phone}:${pin}`, pepper);
}

Deno.serve(async (request) => {
  if (request.method === 'OPTIONS') return new Response('ok', { headers: cors });
  if (request.method !== 'POST') return Response.json({ error: 'Method not allowed' }, { status: 405, headers: cors });
  try {
    const token = request.headers.get('Authorization')?.replace(/^Bearer\s+/i, '');
    if (!token) return Response.json({ error: 'Unauthorized' }, { status: 401, headers: cors });
    const body = await request.json();
    const traineeId = String(body.traineeId ?? '');
    const pin = String(body.pin ?? '');
    if (!/^[0-9a-f-]{36}$/i.test(traineeId) || !/^\d{4}$/.test(pin)) {
      return Response.json({ error: 'Invalid request' }, { status: 400, headers: cors });
    }

    const url = Deno.env.get('SUPABASE_URL')!;
    const secret = keyFromEnv('SUPABASE_SERVICE_ROLE_KEY', 'SUPABASE_SECRET_KEYS');
    const publishable = keyFromEnv('SUPABASE_ANON_KEY', 'SUPABASE_PUBLISHABLE_KEYS');
    const caller = createClient(url, publishable, { auth: { persistSession: false, autoRefreshToken: false } });
    const { data: { user }, error: authError } = await caller.auth.getUser(token);
    if (authError || !user) return Response.json({ error: 'Unauthorized' }, { status: 401, headers: cors });

    const admin = createClient(url, secret, { auth: { persistSession: false, autoRefreshToken: false } });
    const { data: staff, error: staffError } = await admin.from('gym_staff').select('role').eq('user_id', user.id).maybeSingle();
    if (staffError) throw staffError;
    if (staff?.role !== 'admin') return Response.json({ error: 'Administrator access required' }, { status: 403, headers: cors });

    const { data: rows, error: traineeError } = await admin.from('trainees').select('id,phone_e164,auth_user_id').eq('id', traineeId).limit(1);
    if (traineeError) throw traineeError;
    const trainee = rows?.[0];
    if (!trainee) return Response.json({ error: 'Trainee not found' }, { status: 404, headers: cors });
    const phone = normalizePhone(trainee.phone_e164);
    if (!phone || phone !== trainee.phone_e164) return Response.json({ error: 'Trainee phone is invalid' }, { status: 409, headers: cors });
    const { data: samePhone, error: phoneError } = await admin.from('trainees').select('id').eq('phone_e164', phone).limit(2);
    if (phoneError) throw phoneError;
    if ((samePhone || []).length !== 1 || samePhone?.[0]?.id !== trainee.id) {
      return Response.json({ error: 'Phone must identify exactly one trainee' }, { status: 409, headers: cors });
    }

    const pepper = Deno.env.get('MEMBER_PIN_PEPPER');
    if (!pepper || pepper.length < 32) throw new Error('MEMBER_PIN_PEPPER must be configured with at least 32 characters');
    const email = await memberAuthEmail(phone, pepper);
    const password = await deriveAuthPassword(phone, pin, pepper);
    let authUserId = trainee.auth_user_id;
    let createdUser = false;

    if (authUserId) {
      const { data: role } = await admin.from('gym_staff').select('user_id').eq('user_id', authUserId).maybeSingle();
      if (role) return Response.json({ error: 'A staff account cannot be linked as a trainee' }, { status: 409, headers: cors });
      const { error } = await admin.auth.admin.updateUserById(authUserId, { email, email_confirm: true, password });
      if (error) throw error;
    } else {
      const { data: created, error } = await admin.auth.admin.createUser({ email, email_confirm: true, password });
      if (error) throw error;
      authUserId = created.user.id;
      createdUser = true;
      const { data: linked, error: linkError } = await admin.from('trainees').update({ auth_user_id: authUserId })
        .eq('id', trainee.id).is('auth_user_id', null).select('id').maybeSingle();
      if (linkError || !linked) {
        await admin.auth.admin.deleteUser(authUserId);
        if (linkError) throw linkError;
        return Response.json({ error: 'Trainee was linked concurrently; retry after refreshing.' }, { status: 409, headers: cors });
      }
    }
    return Response.json({ configured: true, createdUser }, { headers: cors });
  } catch (error) {
    console.error('set-member-pin failed', error);
    return Response.json({ error: 'Unable to set member PIN' }, { status: 500, headers: cors });
  }
});
