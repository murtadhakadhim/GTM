import { createClient } from 'npm:@supabase/supabase-js@2';

const cors = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
};

function keyFromEnv(legacyName: string, mapName: string): string {
  const legacy = Deno.env.get(legacyName);
  if (legacy) return legacy;
  const keys = JSON.parse(Deno.env.get(mapName) || '{}');
  if (typeof keys.default === 'string') return keys.default;
  throw new Error(`${mapName} is not configured`);
}

Deno.serve(async (request) => {
  if (request.method === 'OPTIONS') return new Response('ok', { headers: cors });
  if (request.method !== 'POST') return Response.json({ error: 'Method not allowed' }, { status: 405, headers: cors });
  try {
    const token = request.headers.get('Authorization')?.replace(/^Bearer\s+/i, '');
    if (!token) return Response.json({ error: 'Unauthorized' }, { status: 401, headers: cors });
    const body = await request.json();
    const name = String(body.name ?? '').trim();
    const email = String(body.email ?? '').trim().toLowerCase();
    const password = String(body.password ?? '');
    if (name.length < 2 || name.length > 100 || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) || password.length < 12) {
      return Response.json({ error: 'Enter a name, valid email, and a password with at least 12 characters.' }, { status: 400, headers: cors });
    }
    const url = Deno.env.get('SUPABASE_URL')!;
    const secret = keyFromEnv('SUPABASE_SERVICE_ROLE_KEY', 'SUPABASE_SECRET_KEYS');
    const publishable = keyFromEnv('SUPABASE_ANON_KEY', 'SUPABASE_PUBLISHABLE_KEYS');
    const caller = createClient(url, publishable, { auth: { persistSession: false, autoRefreshToken: false } });
    const { data: { user }, error: authError } = await caller.auth.getUser(token);
    if (authError || !user) return Response.json({ error: 'Unauthorized' }, { status: 401, headers: cors });
    const admin = createClient(url, secret, { auth: { persistSession: false, autoRefreshToken: false } });
    const { data: callerRole, error: roleError } = await admin.from('gym_staff').select('role').eq('user_id', user.id).maybeSingle();
    if (roleError) throw roleError;
    if (callerRole?.role !== 'admin') return Response.json({ error: 'Administrator access required' }, { status: 403, headers: cors });

    const { data: created, error: createError } = await admin.auth.admin.createUser({
      email, password, email_confirm: true, user_metadata: { full_name: name, systemak_role: 'coach' },
    });
    if (createError) throw createError;
    const { error: insertError } = await admin.from('gym_staff').insert({ user_id: created.user.id, role: 'coach', display_name: name });
    if (insertError) {
      await admin.auth.admin.deleteUser(created.user.id);
      throw insertError;
    }
    return Response.json({ userId: created.user.id, email: created.user.email }, { headers: cors });
  } catch (error) {
    console.error('invite-coach failed', error);
    return Response.json({ error: 'Unable to create coach account. Check that the email is not already in use.' }, { status: 500, headers: cors });
  }
});
