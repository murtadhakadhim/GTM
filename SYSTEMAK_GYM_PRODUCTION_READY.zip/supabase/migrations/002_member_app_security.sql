-- Member phone login, identity linking, staff/member RLS and private media access.
create or replace function public.normalize_iraqi_phone(p_value text)
returns text language sql immutable strict set search_path = pg_catalog
as $$
  with p as (select regexp_replace(p_value, '[^0-9]', '', 'g') as digits)
  select case
    when digits = '' then ''
    when digits like '00964%' then '+' || substring(digits from 3)
    when digits like '964%' then '+' || digits
    when digits like '0%' then '+964' || substring(digits from 2)
    when digits like '7%' then '+964' || digits
    else '+' || digits
  end from p;
$$;

alter table public.trainees add column if not exists phone_e164 text
  generated always as (public.normalize_iraqi_phone(phone)) stored;
alter table public.trainees add column if not exists auth_user_id uuid
  references auth.users(id) on delete set null;
create index if not exists trainees_phone_e164_idx on public.trainees (phone_e164);
create unique index if not exists trainees_auth_user_id_uidx on public.trainees (auth_user_id) where auth_user_id is not null;

create table if not exists public.gym_staff (
  user_id uuid primary key references auth.users(id) on delete cascade,
  role text not null check (role in ('admin','coach')),
  created_at timestamptz not null default now()
);
alter table public.gym_staff enable row level security;
revoke all on public.gym_staff from anon, authenticated;
grant select on public.gym_staff to authenticated;
drop policy if exists "Staff can view own membership" on public.gym_staff;
create policy "Staff can view own membership" on public.gym_staff for select to authenticated using (user_id = (select auth.uid()));

create or replace function public.is_gym_staff()
returns boolean language sql stable security definer set search_path = pg_catalog, public
as $$ select exists (select 1 from public.gym_staff where user_id = (select auth.uid()) and role in ('admin','coach')); $$;
revoke all on function public.is_gym_staff() from public, anon;
grant execute on function public.is_gym_staff() to authenticated;

create or replace function public.is_gym_admin()
returns boolean language sql stable security definer set search_path = pg_catalog, public
as $$ select exists (select 1 from public.gym_staff where user_id = (select auth.uid()) and role = 'admin'); $$;
revoke all on function public.is_gym_admin() from public, anon;
grant execute on function public.is_gym_admin() to authenticated;

create or replace function public.my_trainee_id()
returns uuid language sql stable security definer set search_path = pg_catalog, public
as $$ select id from public.trainees where auth_user_id = (select auth.uid()) limit 1; $$;
revoke all on function public.my_trainee_id() from public, anon;
grant execute on function public.my_trainee_id() to authenticated;

-- Hash-only, short-window throttling for the unauthenticated registered-phone check.
create table if not exists public.member_phone_rate_limits (
  key_hash text primary key,
  window_started_at timestamptz not null default now(),
  attempts integer not null default 0
);
alter table public.member_phone_rate_limits enable row level security;
revoke all on public.member_phone_rate_limits from anon, authenticated;
create or replace function public.consume_member_phone_rate_limit(p_key_hash text, p_max_hits integer, p_window_seconds integer)
returns boolean language plpgsql security definer set search_path = pg_catalog, public
as $$
declare v_attempts integer;
begin
  insert into public.member_phone_rate_limits(key_hash, window_started_at, attempts)
  values (p_key_hash, now(), 1)
  on conflict (key_hash) do update set
    attempts = case when public.member_phone_rate_limits.window_started_at < now() - make_interval(secs => p_window_seconds) then 1 else public.member_phone_rate_limits.attempts + 1 end,
    window_started_at = case when public.member_phone_rate_limits.window_started_at < now() - make_interval(secs => p_window_seconds) then now() else public.member_phone_rate_limits.window_started_at end
  returning attempts into v_attempts;
  return v_attempts <= p_max_hits;
end;
$$;
revoke all on function public.consume_member_phone_rate_limit(text, integer, integer) from public, anon, authenticated;
grant execute on function public.consume_member_phone_rate_limit(text, integer, integer) to service_role;

-- Replace the original all-authenticated policy with staff-only management.
do $$
declare t text;
begin
  foreach t in array array['trainees','courses','course_days','exercises','course_assignments','subscriptions'] loop
    execute format('drop policy if exists "Authenticated staff manage %1$s" on public.%1$I', t);
    execute format('drop policy if exists "Gym staff manage %1$s" on public.%1$I', t);
    execute format('drop policy if exists "Gym admins manage %1$s" on public.%1$I', t);
    execute format('create policy "Gym admins manage %1$s" on public.%1$I for all to authenticated using ((select public.is_gym_admin())) with check ((select public.is_gym_admin()))', t);
    execute format('revoke all on public.%1$I from anon', t);
    execute format('grant select, insert, update, delete on public.%1$I to authenticated', t);
  end loop;
end $$;

drop policy if exists "Coaches can view courses" on public.courses;
create policy "Coaches can view courses" on public.courses for select to authenticated
  using (exists (select 1 from public.gym_staff where user_id = (select auth.uid()) and role = 'coach'));
drop policy if exists "Coaches can view course days" on public.course_days;
create policy "Coaches can view course days" on public.course_days for select to authenticated
  using (exists (select 1 from public.gym_staff where user_id = (select auth.uid()) and role = 'coach'));
drop policy if exists "Coaches manage exercises" on public.exercises;
create policy "Coaches manage exercises" on public.exercises for all to authenticated
  using (exists (select 1 from public.gym_staff where user_id = (select auth.uid()) and role = 'coach'))
  with check (exists (select 1 from public.gym_staff where user_id = (select auth.uid()) and role = 'coach'));

drop policy if exists "Trainees can read own profile" on public.trainees;
create policy "Trainees can read own profile" on public.trainees for select to authenticated using (auth_user_id = (select auth.uid()));
drop policy if exists "Trainees can read own assignment" on public.course_assignments;
create policy "Trainees can read own assignment" on public.course_assignments for select to authenticated using (trainee_id = (select public.my_trainee_id()));
drop policy if exists "Trainees can read assigned course" on public.courses;
create policy "Trainees can read assigned course" on public.courses for select to authenticated using (
  exists (select 1 from public.course_assignments ca where ca.course_id = courses.id and ca.trainee_id = (select public.my_trainee_id()))
);
drop policy if exists "Trainees can read assigned days" on public.course_days;
create policy "Trainees can read assigned days" on public.course_days for select to authenticated using (
  exists (select 1 from public.course_assignments ca where ca.course_id = course_days.course_id and ca.trainee_id = (select public.my_trainee_id()))
);
drop policy if exists "Trainees can read assigned exercises" on public.exercises;
create policy "Trainees can read assigned exercises" on public.exercises for select to authenticated using (
  exists (select 1 from public.course_days d join public.course_assignments ca on ca.course_id = d.course_id
    where d.id = exercises.course_day_id and ca.trainee_id = (select public.my_trainee_id()))
);
drop policy if exists "Trainees can read own subscriptions" on public.subscriptions;
create policy "Trainees can read own subscriptions" on public.subscriptions for select to authenticated using (trainee_id = (select public.my_trainee_id()));

-- Private bucket: staff manage files; members can read only files referenced by assigned exercises.
drop policy if exists "Authenticated staff manage exercise media" on storage.objects;
drop policy if exists "Gym staff manage exercise media" on storage.objects;
drop policy if exists "Gym admins manage exercise media" on storage.objects;
drop policy if exists "Coaches manage exercise media" on storage.objects;
drop policy if exists "Trainees can read assigned exercise media" on storage.objects;
create policy "Gym admins manage exercise media" on storage.objects for all to authenticated
  using (bucket_id = 'exercise-media' and (select public.is_gym_admin()))
  with check (bucket_id = 'exercise-media' and (select public.is_gym_admin()));
create policy "Coaches manage exercise media" on storage.objects for all to authenticated
  using (bucket_id = 'exercise-media' and exists (select 1 from public.gym_staff where user_id = (select auth.uid()) and role = 'coach'))
  with check (bucket_id = 'exercise-media' and exists (select 1 from public.gym_staff where user_id = (select auth.uid()) and role = 'coach'));
create policy "Trainees can read assigned exercise media" on storage.objects for select to authenticated using (
  bucket_id = 'exercise-media' and exists (
    select 1 from public.exercises e join public.course_days d on d.id = e.course_day_id
    join public.course_assignments ca on ca.course_id = d.course_id
    where ca.trainee_id = (select public.my_trainee_id())
      and (e.video_path = storage.objects.name or e.image_path = storage.objects.name)
  )
);

-- Enable live changes on the shared records when Supabase Realtime is available.
do $$
declare t text;
begin
  if exists (select 1 from pg_publication where pubname = 'supabase_realtime') then
    foreach t in array array['trainees','courses','course_days','exercises','course_assignments','subscriptions'] loop
      if not exists (select 1 from pg_publication_tables where pubname = 'supabase_realtime' and schemaname = 'public' and tablename = t) then
        execute format('alter publication supabase_realtime add table public.%I', t);
      end if;
    end loop;
  end if;
end $$;

-- Staff must be explicitly provisioned after their Auth account is created. Example:
-- insert into public.gym_staff(user_id, role)
-- select id, 'admin' from auth.users where email = 'admin@example.com'
-- on conflict (user_id) do update set role = excluded.role;
