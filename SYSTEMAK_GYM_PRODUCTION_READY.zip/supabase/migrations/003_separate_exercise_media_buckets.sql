-- Separate private video and image buckets. Existing objects stay in exercise-media and remain readable.
alter table public.exercises add column if not exists video_bucket text not null default 'exercise-media';
alter table public.exercises add column if not exists image_bucket text;
update public.exercises set image_bucket = 'exercise-media' where image_path is not null and image_bucket is null;

do $$
begin
  if not exists (select 1 from pg_constraint where conname = 'exercises_video_bucket_check') then
    alter table public.exercises add constraint exercises_video_bucket_check check (video_bucket in ('exercise-media','exercise-videos'));
  end if;
  if not exists (select 1 from pg_constraint where conname = 'exercises_image_bucket_check') then
    alter table public.exercises add constraint exercises_image_bucket_check check (image_bucket is null or image_bucket in ('exercise-media','exercise-images'));
  end if;
end $$;

insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values
  ('exercise-videos','exercise-videos',false,209715200,array['video/mp4','video/quicktime','video/webm','video/x-msvideo']),
  ('exercise-images','exercise-images',false,10485760,array['image/jpeg','image/png','image/webp'])
on conflict (id) do update set
  public = false,
  file_size_limit = excluded.file_size_limit,
  allowed_mime_types = excluded.allowed_mime_types;

drop policy if exists "Gym admins manage exercise videos" on storage.objects;
create policy "Gym admins manage exercise videos" on storage.objects for all to authenticated
  using (bucket_id = 'exercise-videos' and (select public.is_gym_admin()))
  with check (bucket_id = 'exercise-videos' and (select public.is_gym_admin()));
drop policy if exists "Coaches manage exercise videos" on storage.objects;
create policy "Coaches manage exercise videos" on storage.objects for all to authenticated
  using (bucket_id = 'exercise-videos' and exists (select 1 from public.gym_staff where user_id = (select auth.uid()) and role = 'coach'))
  with check (bucket_id = 'exercise-videos' and exists (select 1 from public.gym_staff where user_id = (select auth.uid()) and role = 'coach'));
drop policy if exists "Gym admins manage exercise images" on storage.objects;
create policy "Gym admins manage exercise images" on storage.objects for all to authenticated
  using (bucket_id = 'exercise-images' and (select public.is_gym_admin()))
  with check (bucket_id = 'exercise-images' and (select public.is_gym_admin()));
drop policy if exists "Coaches manage exercise images" on storage.objects;
create policy "Coaches manage exercise images" on storage.objects for all to authenticated
  using (bucket_id = 'exercise-images' and exists (select 1 from public.gym_staff where user_id = (select auth.uid()) and role = 'coach'))
  with check (bucket_id = 'exercise-images' and exists (select 1 from public.gym_staff where user_id = (select auth.uid()) and role = 'coach'));

drop policy if exists "Trainees can read assigned exercise media" on storage.objects;
create policy "Trainees can read assigned exercise media" on storage.objects for select to authenticated using (
  bucket_id in ('exercise-media','exercise-videos','exercise-images') and exists (
    select 1 from public.exercises e
    join public.course_days d on d.id = e.course_day_id
    join public.course_assignments ca on ca.course_id = d.course_id
    where ca.trainee_id = (select public.my_trainee_id())
      and ((e.video_path = storage.objects.name and e.video_bucket = storage.objects.bucket_id)
        or (e.image_path = storage.objects.name and e.image_bucket = storage.objects.bucket_id))
  )
);
