-- Retain the training-plan history for each trainee as assignments are changed.
create table if not exists public.trainee_program_history (
  id uuid primary key default gen_random_uuid(),
  trainee_id uuid not null references public.trainees(id) on delete cascade,
  course_id uuid not null references public.courses(id) on delete restrict,
  course_version_id uuid references public.course_versions(id) on delete set null,
  start_date date not null default current_date,
  assigned_by uuid references auth.users(id) on delete set null,
  assigned_at timestamptz not null default now()
);
create index if not exists trainee_program_history_order_idx on public.trainee_program_history(trainee_id, assigned_at desc);
alter table public.trainee_program_history enable row level security;
revoke all on public.trainee_program_history from anon;
grant select on public.trainee_program_history to authenticated;

drop policy if exists "Admins read trainee program history" on public.trainee_program_history;
create policy "Admins read trainee program history" on public.trainee_program_history for select to authenticated
  using ((select public.is_gym_admin()));
drop policy if exists "Coaches read assigned trainee program history" on public.trainee_program_history;
create policy "Coaches read assigned trainee program history" on public.trainee_program_history for select to authenticated
  using (exists(select 1 from public.trainees t where t.id=trainee_id and t.coach_user_id=(select auth.uid())));
drop policy if exists "Trainees read own program history" on public.trainee_program_history;
create policy "Trainees read own program history" on public.trainee_program_history for select to authenticated
  using (trainee_id=(select public.my_trainee_id()));

create or replace function public.capture_trainee_program_assignment()
returns trigger language plpgsql security definer set search_path=pg_catalog, public
as $$
begin
  if tg_op='INSERT' then
    insert into public.trainee_program_history(trainee_id,course_id,course_version_id,start_date,assigned_by)
    values(new.trainee_id,new.course_id,new.course_version_id,new.start_date,auth.uid());
  elsif new.course_id is distinct from old.course_id or new.course_version_id is distinct from old.course_version_id or new.start_date is distinct from old.start_date then
    insert into public.trainee_program_history(trainee_id,course_id,course_version_id,start_date,assigned_by)
    values(new.trainee_id,new.course_id,new.course_version_id,new.start_date,auth.uid());
  end if;
  return new;
end;
$$;
drop trigger if exists course_assignments_capture_history on public.course_assignments;
create trigger course_assignments_capture_history after insert or update on public.course_assignments
  for each row execute function public.capture_trainee_program_assignment();

insert into public.trainee_program_history(trainee_id,course_id,course_version_id,start_date,assigned_at)
select a.trainee_id,a.course_id,a.course_version_id,a.start_date,a.created_at
from public.course_assignments a
where not exists(select 1 from public.trainee_program_history h where h.trainee_id=a.trainee_id);
