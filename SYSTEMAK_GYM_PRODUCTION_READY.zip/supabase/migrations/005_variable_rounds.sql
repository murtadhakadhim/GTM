-- Variable repetitions per exercise without weight/rest metrics.
-- Existing comma-separated repetitions are retained and converted to structured rounds.
alter table public.exercises
  add column if not exists sets_reps jsonb not null default '[]'::jsonb;

update public.exercises
set sets_reps = to_jsonb(array(
  select trim(value)
  from regexp_split_to_table(coalesce(repetitions, ''), E'[,،]') as value
  where trim(value) <> ''
))
where sets_reps = '[]'::jsonb and coalesce(repetitions, '') <> '';

alter table public.exercises
  add constraint exercises_sets_reps_array_check
  check (jsonb_typeof(sets_reps) = 'array');

-- Backfill a version for every existing course and link each current assignment to it.
do $$
declare c record; v uuid;
begin
  for c in select id from public.courses loop
    select id into v from public.course_versions
    where course_id=c.id order by version_number desc limit 1;
    if v is null then v := public.create_course_version(c.id); end if;
    update public.course_assignments set course_version_id=v
      where course_id=c.id and course_version_id is null;
  end loop;
end $$;

-- Members now read the exact immutable program version assigned to them, not the
-- mutable shared course rows. Migration 005 backfills every existing assignment first.
drop policy if exists "Trainees can read assigned course" on public.courses;
drop policy if exists "Trainees can read assigned days" on public.course_days;
drop policy if exists "Trainees can read assigned exercises" on public.exercises;
drop policy if exists "Trainees can read assigned exercise media" on storage.objects;
