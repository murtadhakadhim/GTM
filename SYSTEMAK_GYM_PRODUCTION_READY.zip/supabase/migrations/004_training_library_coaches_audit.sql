-- SYSTEMAK GYM expansion. Additive migration; preserves existing trainees, courses,
-- exercise rows, assignments, subscriptions, and Storage objects.

-- Courses can have any positive number of training days. Existing 3/4 day data stays intact.
alter table public.courses drop constraint if exists courses_training_days_check;
alter table public.courses add constraint courses_training_days_check check (training_days >= 1);
alter table public.course_days drop constraint if exists course_days_day_number_check;
alter table public.course_days add constraint course_days_day_number_check check (day_number >= 1);

-- Explicit staff metadata and ownership links. Existing coach_name remains for backwards compatibility.
alter table public.gym_staff add column if not exists display_name text not null default '';
alter table public.courses add column if not exists coach_user_id uuid references public.gym_staff(user_id) on delete set null;
alter table public.trainees add column if not exists coach_user_id uuid references public.gym_staff(user_id) on delete set null;
create index if not exists trainees_coach_user_idx on public.trainees(coach_user_id);
create index if not exists courses_coach_user_idx on public.courses(coach_user_id);
alter table public.courses add column if not exists archived_at timestamptz;

-- Members may learn only the display name of their own assigned coach.
create or replace function public.member_coach_name()
returns text language sql stable security definer set search_path=pg_catalog, public
as $$
  select coalesce(nullif(s.display_name,''), c.coach_name)
  from public.trainees t
  left join public.gym_staff s on s.user_id=t.coach_user_id
  left join public.course_assignments a on a.trainee_id=t.id
  left join public.courses c on c.id=a.course_id
  where t.auth_user_id=(select auth.uid())
  limit 1
$$;
revoke all on function public.member_coach_name() from public, anon;
grant execute on function public.member_coach_name() to authenticated;

-- Immutable program snapshots keep assigned/older training content unchanged when a course is edited.
create table if not exists public.course_versions (
  id uuid primary key default gen_random_uuid(),
  course_id uuid not null references public.courses(id) on delete cascade,
  version_number integer not null check (version_number > 0),
  snapshot jsonb not null,
  created_by uuid references public.gym_staff(user_id) on delete set null,
  created_at timestamptz not null default now(),
  unique(course_id, version_number)
);
alter table public.course_assignments add column if not exists course_version_id uuid references public.course_versions(id) on delete set null;
create index if not exists course_versions_course_idx on public.course_versions(course_id, version_number desc);
create or replace function public.create_course_version(p_course_id uuid)
returns uuid language plpgsql security definer set search_path = pg_catalog, public
as $$
declare v_course public.courses%rowtype; v_version integer; v_snapshot jsonb; v_id uuid;
begin
  if auth.uid() is not null and not public.is_gym_admin() and not exists(select 1 from public.courses c where c.id=p_course_id and c.coach_user_id=auth.uid()) then
    raise exception 'Not authorized to snapshot this course' using errcode='42501';
  end if;
  select * into v_course from public.courses where id=p_course_id for update;
  if not found then raise exception 'Course not found' using errcode='P0002'; end if;
  select coalesce(max(version_number),0)+1 into v_version from public.course_versions where course_id=p_course_id;
  select jsonb_build_object(
    'course', to_jsonb(v_course),
    'days', coalesce((select jsonb_agg(jsonb_build_object(
      'day', to_jsonb(d),
      'muscles', coalesce((select jsonb_agg(t.name order by t.name) from public.course_day_muscles dm join public.exercise_tags t on t.id=dm.tag_id where dm.course_day_id=d.id),'[]'::jsonb),
      'exercises', coalesce((select jsonb_agg(to_jsonb(e) order by e.sort_order, e.created_at) from public.exercises e where e.course_day_id=d.id),'[]'::jsonb)
    ) order by d.day_number) from public.course_days d where d.course_id=p_course_id),'[]'::jsonb)
  ) into v_snapshot;
  insert into public.course_versions(course_id,version_number,snapshot,created_by)
  values(p_course_id,v_version,v_snapshot,auth.uid()) returning id into v_id;
  return v_id;
end;
$$;
revoke all on function public.create_course_version(uuid) from public, anon;
grant execute on function public.create_course_version(uuid) to authenticated;

-- Central reusable exercise definitions. Training-day exercises remain independent snapshots
-- in public.exercises; a later library edit never mutates an existing workout item.
create table if not exists public.exercise_library (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  video_path text not null,
  video_bucket text not null default 'exercise-videos' check (video_bucket in ('exercise-media','exercise-videos')),
  image_path text,
  image_bucket text check (image_bucket is null or image_bucket in ('exercise-media','exercise-images')),
  notes text not null default '',
  created_by uuid references public.gym_staff(user_id) on delete set null,
  archived_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index if not exists exercise_library_name_idx on public.exercise_library using gin (to_tsvector('simple', name));
create index if not exists exercise_library_active_idx on public.exercise_library (created_at desc) where archived_at is null;
alter table public.exercises add column if not exists library_exercise_id uuid references public.exercise_library(id) on delete set null;

-- Taxonomies are normalized: one exercise may have many muscles, equipment items, and categories.
create table if not exists public.exercise_tags (
  id uuid primary key default gen_random_uuid(),
  kind text not null check (kind in ('muscle','equipment','category')),
  name text not null,
  created_at timestamptz not null default now(),
  unique(kind, name)
);
create table if not exists public.exercise_library_tags (
  exercise_id uuid not null references public.exercise_library(id) on delete cascade,
  tag_id uuid not null references public.exercise_tags(id) on delete restrict,
  primary key (exercise_id, tag_id)
);
create index if not exists exercise_library_tags_tag_idx on public.exercise_library_tags(tag_id);
create table if not exists public.course_day_muscles (
  course_day_id uuid not null references public.course_days(id) on delete cascade,
  tag_id uuid not null references public.exercise_tags(id) on delete restrict,
  primary key (course_day_id, tag_id)
);

-- Coach proposals are separate from the shared library until approved by an admin.
create table if not exists public.exercise_requests (
  id uuid primary key default gen_random_uuid(),
  submitted_by uuid not null references public.gym_staff(user_id) on delete cascade,
  name text not null,
  video_path text not null,
  video_bucket text not null default 'exercise-videos' check (video_bucket in ('exercise-media','exercise-videos')),
  image_path text,
  image_bucket text check (image_bucket is null or image_bucket in ('exercise-media','exercise-images')),
  notes text not null default '',
  muscle_tags text[] not null default '{}',
  equipment_tags text[] not null default '{}',
  category_tags text[] not null default '{}',
  status text not null default 'pending' check (status in ('pending','approved','rejected')),
  review_note text not null default '',
  reviewed_by uuid references public.gym_staff(user_id) on delete set null,
  reviewed_at timestamptz,
  library_exercise_id uuid references public.exercise_library(id) on delete set null,
  created_at timestamptz not null default now()
);
create index if not exists exercise_requests_pending_idx on public.exercise_requests(created_at desc) where status='pending';

-- Preserve a history point whenever the current profile weight changes.
create table if not exists public.trainee_weight_history (
  id uuid primary key default gen_random_uuid(),
  trainee_id uuid not null references public.trainees(id) on delete cascade,
  weight numeric(5,1) not null check (weight > 0),
  recorded_at timestamptz not null default now(),
  recorded_by uuid references auth.users(id) on delete set null
);
create index if not exists trainee_weight_history_order_idx on public.trainee_weight_history(trainee_id, recorded_at desc);
create or replace function public.record_trainee_weight_change()
returns trigger language plpgsql security definer set search_path = pg_catalog, public
as $$
begin
  if tg_op = 'INSERT' then
    insert into public.trainee_weight_history(trainee_id, weight, recorded_by)
    values (new.id, new.weight, auth.uid());
  elsif new.weight is distinct from old.weight then
    insert into public.trainee_weight_history(trainee_id, weight, recorded_by)
    values (new.id, new.weight, auth.uid());
  end if;
  return new;
end;
$$;
drop trigger if exists trainees_record_weight_change on public.trainees;
create trigger trainees_record_weight_change after insert or update of weight on public.trainees
for each row execute function public.record_trainee_weight_change();
-- Record a baseline for existing profiles exactly once, without changing their current weight.
insert into public.trainee_weight_history(trainee_id, weight, recorded_at)
select t.id, t.weight, t.created_at from public.trainees t
where not exists (select 1 from public.trainee_weight_history h where h.trainee_id=t.id);

-- Append-only audit events for critical record changes.
create table if not exists public.gym_audit_log (
  id bigint generated always as identity primary key,
  actor_user_id uuid references auth.users(id) on delete set null,
  action text not null check (action in ('INSERT','UPDATE','DELETE')),
  table_name text not null,
  record_id text not null,
  occurred_at timestamptz not null default now(),
  old_data jsonb,
  new_data jsonb
);
create index if not exists gym_audit_log_time_idx on public.gym_audit_log(occurred_at desc);
create or replace function public.capture_gym_audit_event()
returns trigger language plpgsql security definer set search_path = pg_catalog, public
as $$
declare old_row jsonb; new_row jsonb; row_id text;
begin
  if tg_op <> 'INSERT' then old_row := to_jsonb(old); end if;
  if tg_op <> 'DELETE' then new_row := to_jsonb(new); end if;
  row_id := coalesce(new_row->>'id', old_row->>'id', new_row->>'user_id', old_row->>'user_id', 'unknown');
  insert into public.gym_audit_log(actor_user_id, action, table_name, record_id, old_data, new_data)
  values (auth.uid(), tg_op, tg_table_name, row_id, old_row, new_row);
  if tg_op = 'DELETE' then return old; end if;
  return new;
end;
$$;
do $$
declare t text;
begin
  foreach t in array array['trainees','courses','course_days','exercises','course_assignments','course_versions','subscriptions','exercise_library','exercise_requests'] loop
    execute format('drop trigger if exists gym_audit_%1$I on public.%1$I', t);
    execute format('create trigger gym_audit_%1$I after insert or update or delete on public.%1$I for each row execute function public.capture_gym_audit_event()', t);
  end loop;
end $$;

-- RLS for new tables and explicit role scopes.
alter table public.exercise_library enable row level security;
alter table public.course_versions enable row level security;
alter table public.exercise_tags enable row level security;
alter table public.exercise_library_tags enable row level security;
alter table public.course_day_muscles enable row level security;
alter table public.exercise_requests enable row level security;
alter table public.trainee_weight_history enable row level security;
alter table public.gym_audit_log enable row level security;

drop policy if exists "Admins manage exercise library" on public.exercise_library;
create policy "Admins manage exercise library" on public.exercise_library for all to authenticated
  using ((select public.is_gym_admin())) with check ((select public.is_gym_admin()));
drop policy if exists "Coaches read active exercise library" on public.exercise_library;
create policy "Coaches read active exercise library" on public.exercise_library for select to authenticated
  using (archived_at is null and exists (select 1 from public.gym_staff s where s.user_id=(select auth.uid()) and s.role='coach'));

drop policy if exists "Admins manage course versions" on public.course_versions;
create policy "Admins manage course versions" on public.course_versions for all to authenticated
  using ((select public.is_gym_admin())) with check ((select public.is_gym_admin()));
drop policy if exists "Coaches manage assigned course versions" on public.course_versions;
create policy "Coaches manage assigned course versions" on public.course_versions for all to authenticated
  using (exists(select 1 from public.courses c where c.id=course_id and c.coach_user_id=(select auth.uid())))
  with check (exists(select 1 from public.courses c where c.id=course_id and c.coach_user_id=(select auth.uid())));
drop policy if exists "Members read assigned course version" on public.course_versions;
create policy "Members read assigned course version" on public.course_versions for select to authenticated
  using (exists(select 1 from public.course_assignments a where a.course_version_id=course_versions.id and a.trainee_id=(select public.my_trainee_id())));

drop policy if exists "Admins manage exercise tags" on public.exercise_tags;
create policy "Admins manage exercise tags" on public.exercise_tags for all to authenticated
  using ((select public.is_gym_admin())) with check ((select public.is_gym_admin()));
drop policy if exists "Staff read exercise tags" on public.exercise_tags;
create policy "Staff read exercise tags" on public.exercise_tags for select to authenticated using ((select public.is_gym_staff()));
drop policy if exists "Admins manage library tag links" on public.exercise_library_tags;
create policy "Admins manage library tag links" on public.exercise_library_tags for all to authenticated
  using ((select public.is_gym_admin())) with check ((select public.is_gym_admin()));
drop policy if exists "Staff read active library tag links" on public.exercise_library_tags;
create policy "Staff read active library tag links" on public.exercise_library_tags for select to authenticated
  using (exists (select 1 from public.exercise_library l where l.id=exercise_id and l.archived_at is null));
drop policy if exists "Admins manage day muscles" on public.course_day_muscles;
create policy "Admins manage day muscles" on public.course_day_muscles for all to authenticated
  using ((select public.is_gym_admin())) with check ((select public.is_gym_admin()));
drop policy if exists "Coaches manage assigned day muscles" on public.course_day_muscles;
create policy "Coaches manage assigned day muscles" on public.course_day_muscles for all to authenticated
  using (exists(select 1 from public.course_days d join public.courses c on c.id=d.course_id where d.id=course_day_id and c.coach_user_id=(select auth.uid())))
  with check (exists(select 1 from public.course_days d join public.courses c on c.id=d.course_id where d.id=course_day_id and c.coach_user_id=(select auth.uid())));
drop policy if exists "Members read assigned day muscles" on public.course_day_muscles;
create policy "Members read assigned day muscles" on public.course_day_muscles for select to authenticated
  using (exists(select 1 from public.course_days d join public.course_assignments a on a.course_id=d.course_id where d.id=course_day_id and a.trainee_id=(select public.my_trainee_id())));

drop policy if exists "Coaches create own exercise requests" on public.exercise_requests;
create policy "Coaches create own exercise requests" on public.exercise_requests for insert to authenticated
  with check (submitted_by=(select auth.uid()) and status='pending' and reviewed_by is null and reviewed_at is null);
drop policy if exists "Coaches read own exercise requests" on public.exercise_requests;
create policy "Coaches read own exercise requests" on public.exercise_requests for select to authenticated
  using (submitted_by=(select auth.uid()));
drop policy if exists "Admins review exercise requests" on public.exercise_requests;
create policy "Admins review exercise requests" on public.exercise_requests for all to authenticated
  using ((select public.is_gym_admin())) with check ((select public.is_gym_admin()));

drop policy if exists "Admins view trainee weight history" on public.trainee_weight_history;
create policy "Admins view trainee weight history" on public.trainee_weight_history for all to authenticated
  using ((select public.is_gym_admin())) with check ((select public.is_gym_admin()));
drop policy if exists "Coaches view assigned trainee weight history" on public.trainee_weight_history;
create policy "Coaches view assigned trainee weight history" on public.trainee_weight_history for select to authenticated
  using (exists(select 1 from public.trainees t where t.id=trainee_id and t.coach_user_id=(select auth.uid())));
drop policy if exists "Trainees view own weight history" on public.trainee_weight_history;
create policy "Trainees view own weight history" on public.trainee_weight_history for select to authenticated
  using (trainee_id=(select public.my_trainee_id()));

drop policy if exists "Admins view audit log" on public.gym_audit_log;
create policy "Admins view audit log" on public.gym_audit_log for select to authenticated using ((select public.is_gym_admin()));
revoke all on public.gym_audit_log from anon, authenticated;
grant select on public.gym_audit_log to authenticated;

-- Admins may provision/list staff; staff may read their own row (policy from migration 002 retained).
drop policy if exists "Admins manage gym staff" on public.gym_staff;
create policy "Admins manage gym staff" on public.gym_staff for all to authenticated
  using ((select public.is_gym_admin())) with check ((select public.is_gym_admin()));

-- Restrict coach access to explicitly assigned courses and trainees. Admin/member policies stay intact.
drop policy if exists "Coaches can view courses" on public.courses;
drop policy if exists "Coaches can view course days" on public.course_days;
drop policy if exists "Coaches manage exercises" on public.exercises;
drop policy if exists "Coaches can read assigned trainees" on public.trainees;
create policy "Coaches manage assigned courses" on public.courses for all to authenticated
  using (coach_user_id=(select auth.uid()) and exists(select 1 from public.gym_staff s where s.user_id=(select auth.uid()) and s.role='coach'))
  with check (coach_user_id=(select auth.uid()) and exists(select 1 from public.gym_staff s where s.user_id=(select auth.uid()) and s.role='coach'));
create policy "Coaches manage assigned course days" on public.course_days for all to authenticated
  using (exists(select 1 from public.courses c where c.id=course_id and c.coach_user_id=(select auth.uid())))
  with check (exists(select 1 from public.courses c where c.id=course_id and c.coach_user_id=(select auth.uid())));
create policy "Coaches manage assigned course exercises" on public.exercises for all to authenticated
  using (exists(select 1 from public.course_days d join public.courses c on c.id=d.course_id where d.id=course_day_id and c.coach_user_id=(select auth.uid())))
  with check (exists(select 1 from public.course_days d join public.courses c on c.id=d.course_id where d.id=course_day_id and c.coach_user_id=(select auth.uid())));
create policy "Coaches read assigned trainees" on public.trainees for select to authenticated
  using (coach_user_id=(select auth.uid()));
drop policy if exists "Coaches record assigned trainee weights" on public.trainees;
create policy "Coaches record assigned trainee weights" on public.trainees for update to authenticated
  using (coach_user_id=(select auth.uid()))
  with check (coach_user_id=(select auth.uid()));
create policy "Coaches manage assigned trainee course" on public.course_assignments for all to authenticated
  using (exists(select 1 from public.trainees t join public.courses c on c.id=course_id where t.id=trainee_id and t.coach_user_id=(select auth.uid()) and c.coach_user_id=(select auth.uid())))
  with check (exists(select 1 from public.trainees t join public.courses c on c.id=course_id where t.id=trainee_id and t.coach_user_id=(select auth.uid()) and c.coach_user_id=(select auth.uid())));
create policy "Coaches read assigned subscriptions" on public.subscriptions for select to authenticated
  using (exists(select 1 from public.trainees t where t.id=trainee_id and t.coach_user_id=(select auth.uid())));

-- Remove the broad coach Storage policies from migrations 002/003. Admin policies and member
-- assigned-workout read policies remain. Coach exercise uploads are allowed only under their UID path.
drop policy if exists "Coaches manage exercise media" on storage.objects;
drop policy if exists "Coaches manage exercise videos" on storage.objects;
drop policy if exists "Coaches manage exercise images" on storage.objects;
create policy "Coaches read assigned exercise media" on storage.objects for select to authenticated
  using (bucket_id in ('exercise-media','exercise-videos','exercise-images') and exists (
    select 1 from public.exercises e join public.course_days d on d.id=e.course_day_id join public.courses c on c.id=d.course_id
    where c.coach_user_id=(select auth.uid()) and
      ((e.video_path=storage.objects.name and e.video_bucket=storage.objects.bucket_id) or (e.image_path=storage.objects.name and e.image_bucket=storage.objects.bucket_id))
  ));
create policy "Coaches read active library exercise media" on storage.objects for select to authenticated
  using (bucket_id in ('exercise-media','exercise-videos','exercise-images') and exists (
    select 1 from public.exercise_library l where l.archived_at is null and
      ((l.video_path=storage.objects.name and l.video_bucket=storage.objects.bucket_id) or (l.image_path=storage.objects.name and l.image_bucket=storage.objects.bucket_id))
  ));
create policy "Coaches read own proposed exercise media" on storage.objects for select to authenticated
  using (bucket_id in ('exercise-media','exercise-videos','exercise-images') and exists (
    select 1 from public.exercise_requests r where r.submitted_by=(select auth.uid()) and
      ((r.video_path=storage.objects.name and r.video_bucket=storage.objects.bucket_id) or (r.image_path=storage.objects.name and r.image_bucket=storage.objects.bucket_id))
  ));
create policy "Members read assigned version media" on storage.objects for select to authenticated
  using (bucket_id in ('exercise-media','exercise-videos','exercise-images') and exists (
    select 1 from public.course_versions cv
    join public.course_assignments ca on ca.course_version_id=cv.id
    cross join lateral jsonb_array_elements(coalesce(cv.snapshot->'days','[]'::jsonb)) as day_entry(value)
    cross join lateral jsonb_array_elements(coalesce(day_entry.value->'exercises','[]'::jsonb)) as exercise_entry(value)
    where ca.trainee_id=(select public.my_trainee_id()) and
      ((exercise_entry.value->>'video_path'=storage.objects.name and coalesce(exercise_entry.value->>'video_bucket','exercise-media')=storage.objects.bucket_id)
       or (exercise_entry.value->>'image_path'=storage.objects.name and coalesce(exercise_entry.value->>'image_bucket','exercise-media')=storage.objects.bucket_id))
  ));
create policy "Coaches upload own workout media" on storage.objects for insert to authenticated
  with check (bucket_id in ('exercise-media','exercise-videos','exercise-images') and name like ('%/'||(select auth.uid())||'/%') and exists (
    select 1 from public.gym_staff s where s.user_id=(select auth.uid()) and s.role='coach'
  ));
create policy "Coaches update own workout media" on storage.objects for update to authenticated
  using (bucket_id in ('exercise-media','exercise-videos','exercise-images') and name like ('%/'||(select auth.uid())||'/%'))
  with check (bucket_id in ('exercise-media','exercise-videos','exercise-images') and name like ('%/'||(select auth.uid())||'/%'));
create policy "Coaches delete own workout media" on storage.objects for delete to authenticated
  using (bucket_id in ('exercise-media','exercise-videos','exercise-images') and name like ('%/'||(select auth.uid())||'/%'));

-- Keep new tables private by default and grant only the API permissions RLS will scope.
revoke all on public.exercise_library, public.exercise_tags, public.exercise_library_tags,
  public.course_day_muscles, public.exercise_requests, public.trainee_weight_history from anon;
revoke all on public.course_versions from anon;
grant select, insert, update, delete on public.course_versions to authenticated;
grant select, insert, update, delete on public.exercise_library, public.exercise_tags,
  public.exercise_library_tags, public.course_day_muscles, public.exercise_requests,
  public.trainee_weight_history to authenticated;
grant usage, select on sequence public.gym_audit_log_id_seq to authenticated;

