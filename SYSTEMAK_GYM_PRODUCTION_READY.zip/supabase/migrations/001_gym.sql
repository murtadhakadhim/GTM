-- SYSTEMAK GYM schema. Run once in the Supabase SQL editor.
create extension if not exists pgcrypto;

create table if not exists public.trainees (
  id uuid primary key default gen_random_uuid(), full_name text not null, phone text not null,
  age integer not null check (age between 1 and 110), weight numeric(5,1) not null check (weight > 0),
  height numeric(5,1) not null check (height > 0), created_at timestamptz not null default now()
);
create index if not exists trainees_name_idx on public.trainees (full_name);
create index if not exists trainees_phone_idx on public.trainees (phone);

create table if not exists public.courses (
  id uuid primary key default gen_random_uuid(), name text not null, description text not null default '',
  coach_name text not null default '', training_days integer not null check (training_days in (3,4)),
  created_at timestamptz not null default now()
);
create table if not exists public.course_days (
  id uuid primary key default gen_random_uuid(), course_id uuid not null references public.courses(id) on delete cascade,
  day_number integer not null check (day_number between 1 and 4), name text not null,
  created_at timestamptz not null default now(), unique(course_id, day_number)
);
create table if not exists public.exercises (
  id uuid primary key default gen_random_uuid(), course_day_id uuid not null references public.course_days(id) on delete cascade,
  name text not null, repetitions text not null, image_path text, video_path text not null, notes text not null default '',
  sort_order integer not null default 0, created_at timestamptz not null default now()
);
create index if not exists exercises_day_order_idx on public.exercises (course_day_id, sort_order);
create table if not exists public.course_assignments (
  id uuid primary key default gen_random_uuid(), trainee_id uuid not null unique references public.trainees(id) on delete cascade,
  course_id uuid not null references public.courses(id) on delete restrict, start_date date not null default current_date,
  created_at timestamptz not null default now()
);
create table if not exists public.subscriptions (
  id uuid primary key default gen_random_uuid(), trainee_id uuid not null references public.trainees(id) on delete cascade,
  plan_type text not null check (plan_type in ('weekly','monthly')), start_date date not null, expires_at date not null,
  created_at timestamptz not null default now(), check (expires_at >= start_date)
);
create index if not exists subscriptions_expiry_idx on public.subscriptions (expires_at);

alter table public.trainees enable row level security;
alter table public.courses enable row level security;
alter table public.course_days enable row level security;
alter table public.exercises enable row level security;
alter table public.course_assignments enable row level security;
alter table public.subscriptions enable row level security;

-- This single-gym staff console grants access only to authenticated staff accounts.
do $$
declare t text;
begin
  foreach t in array array['trainees','courses','course_days','exercises','course_assignments','subscriptions'] loop
    execute format('drop policy if exists "Authenticated staff manage %1$s" on public.%1$I', t);
    execute format('create policy "Authenticated staff manage %1$s" on public.%1$I for all to authenticated using (true) with check (true)', t);
    execute format('grant select, insert, update, delete on public.%1$I to authenticated', t);
  end loop;
end $$;

insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values ('exercise-media', 'exercise-media', false, 209715200,
  array['video/mp4','video/quicktime','video/webm','video/x-msvideo','image/jpeg','image/png','image/webp'])
on conflict (id) do update set public = false, file_size_limit = 209715200;
drop policy if exists "Authenticated staff manage exercise media" on storage.objects;
create policy "Authenticated staff manage exercise media" on storage.objects
  for all to authenticated using (bucket_id = 'exercise-media') with check (bucket_id = 'exercise-media');
