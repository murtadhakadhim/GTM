# Production Deployment

## Selected hosting target

Cloudflare Pages is prepared for this Vite SPA. Its current React/Vite build preset uses `npm run build` and outputs `dist`. The `public/_redirects` file preserves SPA routes such as `/member`. Supabase remains the backend; Cloudflare does not host or replace the database.

## Before deployment

1. Create/configure one Supabase project as described in `SUPABASE_SETUP.md`.
2. Apply all migrations in order, set a protected `MEMBER_PIN_PEPPER`, and deploy `member-pin-login` plus `set-member-pin`.
3. Provision staff membership, check phone uniqueness, set a test trainee PIN, and verify access. Member sign-in does not use SMS/OTP. Configure optional Turnstile if desired.
4. Confirm `.env.example` values have matching production values. Do not commit `.env`.
5. Push the project folder to a new GitHub repository. Exclude `node_modules`, `.env*` except `.env.example`, `work`, and local editor files.

## Cloudflare Pages Git deployment

1. In Cloudflare Dashboard, open **Workers & Pages → Create application → Pages → Connect to Git**.
2. Select the GitHub repository.
3. Set the production branch to `main`.
4. Set build command to `npm run build` and build output directory to `dist`.
5. Add the build-time variables `VITE_SUPABASE_URL`, `VITE_SUPABASE_ANON_KEY`, and, if using Turnstile, `VITE_SUPABASE_CAPTCHA_SITE_KEY` under the Pages project variables. Use separate values for Preview and Production if separate Supabase projects are used.
6. Deploy. Check both `/` and `/member`, then check Auth redirect/site URLs and Supabase Auth rate limits against the final Pages hostname.

Cloudflare Pages will build on repository updates. Do not place a Supabase secret/service-role key in Pages variables prefixed with `VITE_`.

## Local verification

```powershell
npm ci
npm run build
npm run preview
```

The project is prepared for deployment but is not deployed. Hosting accounts and production credentials were not provided.
