# System Test Report

Date: 2026-11-23

## Completed locally

- `npm.cmd run build` — passed with Vite 7.3.8 after implementing the administration/member workflows and variable exercise rounds.
- Static source review confirmed the member UI selects its assigned course snapshot when one exists and requests media through private Storage signed URLs.
- No application tables, Auth users, secrets, or remote project settings were modified in this work session.

## Not verified against Supabase

This workspace did not run the production migrations, use the connected production credentials, or upload media. These checks remain pending and are not claimed as passed:

- Apply/re-run behavior of migrations 004–006 against a backup of the intended project.
- Admin, coach and trainee login and complete RLS denial/isolation cases.
- Course creation with 3, 4 and arbitrary day counts; edit, rename and ordering.
- Coach creation, assignment, library proposal/review and access boundaries.
- Round add/remove/edit, batch library addition, reordering and per-trainee version assignment.
- PIN login, subscription renewal history and same-day expiry alert.
- Video upload/replacement, progress, signed playback and historical snapshot playback.
- Weight history recording/chart, audit log and report filters.
- Deployed hosting and browser checks on desktop, tablet and phone.

## Acceptance plan

1. Back up the Supabase project and apply migrations 004, 005, then 006 in that order (001–003 should already be present).
2. Deploy `invite-coach`; keep the existing `MEMBER_PIN_PEPPER` unchanged.
3. Create a designated test trainee and coach in the admin panel. Avoid using unrelated members for test data.
4. Test course creation/editing, individual round counts, library filters/bulk addition, video upload/replacement, ordering and trainee-specific assignment snapshots.
5. Test member PIN login, signed video playback and view-only behavior.
6. Test coach access against a second trainee/course not assigned to that coach; confirm denial.
7. Test subscription renewal, date filters, expiry-today alerts, weight history, and reports.
8. Remove any designated test records only after verifying they have no production assignments or historical audit needs.

Do not mark the project production-ready until these live checks pass on the target Supabase project and deployed site.
