# Supabase Setup

## One project, two interfaces

The dashboard and `/member` route use the same Supabase URL, Auth project, Postgres rows, and Storage. The browser receives only the publishable/anon key; RLS protects data. Never add a secret/service-role key to `.env` variables beginning `VITE_`.

## Apply database migrations

Create or select the intended Supabase project, then apply these files in order using either the Supabase CLI or SQL Editor:

1. `supabase/migrations/001_gym.sql`
2. `supabase/migrations/002_member_app_security.sql`
3. `supabase/migrations/003_separate_exercise_media_buckets.sql`
4. `supabase/migrations/004_training_library_coaches_audit.sql`
5. `supabase/migrations/005_variable_rounds.sql`
6. `supabase/migrations/006_trainee_program_history.sql`

Run them in order without enabling public accounts between migration 001 and 002. Migrations 004–006 add exercise library/tags, coach assignment and isolation, historical course versions, flexible days, variable rounds, weight/program history, request review, and audit records. Existing trainees, subscriptions, courses, exercises and media remain in place. Read the migration files and check the target project before applying them. `seed.sql` deliberately contains no fabricated rows.

For a CLI workflow, install the Supabase CLI, then:

```sh
supabase login
supabase link --project-ref YOUR_PROJECT_REF
supabase db push
```

Choose either the CLI migration workflow or applying SQL manually; do not switch methods without reconciling the CLI migration history.

## Environment

Copy `.env.example` to `.env` and fill:

```env
VITE_SUPABASE_URL=https://YOUR_PROJECT_REF.supabase.co
VITE_SUPABASE_ANON_KEY=YOUR_PUBLISHABLE_OR_ANON_KEY
VITE_SUPABASE_CAPTCHA_SITE_KEY=YOUR_TURNSTILE_SITE_KEY
```

The CAPTCHA site key is optional unless Supabase CAPTCHA protection is enabled. Restart Vite after changing `.env`.

## Staff access

Create an Auth account for the gym administrator, then provision it as staff with a SQL statement in the Supabase SQL Editor:

```sql
insert into public.gym_staff(user_id, role)
select id, 'admin' from auth.users where email = 'ADMIN_EMAIL'
on conflict (user_id) do update set role = excluded.role;
```

Repeat for each coach with role `'coach'`; set `gym_staff.display_name` for the staff directory. After migration 004 and deploying `invite-coach`, the admin can create coach accounts and assign trainees/courses from the dashboard. The migration scopes coach course, trainee, assignment, exercise, and media access to those links.

## Edge Functions

Set the private PIN pepper and deploy the functions with the CLI linked to the correct project:

```sh
supabase functions deploy member-pin-login
supabase functions deploy set-member-pin
supabase functions deploy invite-coach
```

Do not replace or rotate the existing `MEMBER_PIN_PEPPER`; changing it invalidates stored PIN verifiers. Only configure it if it is genuinely absent, using a unique protected value and a planned PIN reset. Hosted Supabase functions inject project URL and API key variables. Keep every secret server-side. No SMS provider is used. The admin dashboard must be signed in as a provisioned `admin` to create/reset a member PIN.

`invite-coach` checks that the caller is an admin before creating a confirmed Auth user and matching `gym_staff` coach row. The initial staff password is supplied by the admin and must be delivered privately; do not reuse a member PIN. Set coach assignments for the course and trainees before granting access; RLS limits coach access to linked records.

## Realtime

Migration 002 adds the shared member-facing tables to `supabase_realtime` when that publication exists. The member app also re-queries on a fresh session/page load, so refresh is the fallback if Realtime is unavailable.
