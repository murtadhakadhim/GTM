# Storage Setup

## Buckets

- `exercise-videos`: private; MP4, MOV, WebM, AVI; max 200 MiB per file.
- `exercise-images`: private; JPG, PNG, WebP; max 10 MiB per file.
- `exercise-media`: retained as a private compatibility bucket for existing media paths. Migration 003 does not move/delete its files.

Migration 001 creates the original media bucket; migration 002 scopes its policies; migration 003 creates the new image/video buckets and adds bucket names to exercise rows. Existing media stays where it is. New uploads use the separated buckets. No permanent public URLs are generated.

## Access

- Admins and coaches can manage exercise media according to their staff role.
- Members can read only an object referenced by an exercise in their currently assigned course.
- The member UI requests a short-lived signed URL when the image is shown or the video page opens. Exercise videos are not preloaded with the day list.

## Validation and cleanup

The UI checks MIME type and size before upload; Storage enforces the same bucket allow-list and size caps. Upload progress reflects actual transfer events. If the database save fails, a newly uploaded object is removed. Replaced/deleted exercise media is cleaned from its recorded bucket. Legacy rows without bucket values are treated as `exercise-media`.

Review Storage usage and current project plan limits in the Supabase Dashboard before production. No fixed free-plan capacity is promised here because plan limits can change.
