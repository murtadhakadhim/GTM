# Authentication Setup

## Staff

1. Create email/password Auth users in Supabase Authentication.
2. Provision each trusted account into `public.gym_staff` as `admin` or `coach` using the SQL in `SUPABASE_SETUP.md`.
3. Dashboard routes require Auth and database RLS checks the staff role.

## Trainee phone + 4-digit PIN (no SMS)

Members sign in with their registered phone number and a four-digit PIN. There is no SMS or OTP step. An administrator creates the trainee record and sets the PIN in the trainee form; on later edits, entering a PIN resets it. Give the PIN to the member directly. The PIN itself is sent only to the protected `set-member-pin` Edge Function and is never stored in the trainee table. The function provisions a confirmed internal Supabase Auth email alias and a long HMAC-derived password; the alias is not used to send email. Phone Auth and an SMS provider are not required.

1. Set a stable, random secret of at least 32 characters for `MEMBER_PIN_PEPPER` in Supabase Functions. Keep it private and back it up securely; changing or losing it prevents existing PINs from working until an admin resets them.
2. Deploy `member-pin-login` and `set-member-pin` as described in `SUPABASE_SETUP.md`.
3. Provision the administrator in `gym_staff` before setting member PINs.
4. Create a trainee with a unique Iraqi mobile number and a four-digit PIN. Duplicate phone records must be cleaned up before enabling a PIN.
5. Member page `/member` accepts the local `07...` or international `+964...` phone form with the PIN. A server-side limiter allows up to five attempts per phone and 30 per IP in ten minutes. Configure optional Supabase CAPTCHA/Turnstile for additional protection.

A four-digit PIN is low entropy. The rate limit, private server-side pepper, generic credential errors, and admin-managed resets reduce exposure but do not make it equivalent to a strong password or a verified SMS factor. There is no self-service PIN recovery; the member contacts the gym administrator. Protect the member's phone number and PIN, and reset the PIN if a device or PIN is exposed.

## Logout and persisted session

The Supabase browser client persists the Auth session, and the member account page provides logout. A fresh page/session reload re-queries the linked profile and current assignment.
