# SYSTEMAK GYM Member App Integration Report

## Shared structures reused

The member website reads existing trainee, assignment, course, training-day, exercise, and subscription rows. Existing media remains in private `exercise-media`; new files use private `exercise-images` and `exercise-videos` buckets. It does not create duplicate gym records.

## Authentication and data flow

- `/member` accepts the registered phone plus a four-digit PIN. No SMS or OTP is sent.
- An admin provisions or resets the PIN through `set-member-pin`. The function creates/updates an internal confirmed Supabase Auth email alias and links its UID to exactly one existing trainee row. A server-only HMAC pepper derives the Auth identity and password; the alias does not send email and the PIN is not stored in Postgres.
- `member-pin-login` rate-limits by HMAC-hashed phone and IP (five tries per phone and 30 per IP per ten minutes), then returns a Supabase Auth session after successful phone/password authentication.
- RLS limits each member to their own profile, single course assignment, that course's days and exercises, subscriptions, and referenced private media. Staff accounts cannot use the member route.
- The member interface refreshes on Realtime changes and page reload. Exercise playback uses short-lived signed URLs.

## Schema and security

Migrations `001_gym.sql`, `002_member_app_security.sql`, and `003_separate_exercise_media_buckets.sql` add the gym schema, role-scoped RLS, normalized unique identity link, PIN-login throttling table/RPC, and private media buckets. Duplicate normalized phone records must be resolved before PIN setup. The private `MEMBER_PIN_PEPPER` must be backed up; losing/changing it requires admin PIN resets. Four-digit PINs are low entropy and are protected by server-side throttling; there is no self-service recovery.

## Verification

- `npm run build`: **passed** locally.
- Browser sign-in, Edge Function deployment, SQL migration/RLS execution, PIN throttling, live assignment synchronization, and private media playback: **not run**. No Supabase project or Auth session is connected in this workspace.

## Remaining setup

1. Apply migrations 001–003 in order.
2. Configure `MEMBER_PIN_PEPPER` and deploy `member-pin-login` and `set-member-pin`.
3. Provision staff Auth users as admin/coach in `gym_staff`.
4. Set a unique phone and PIN for a trainee through the admin dashboard.
5. Run the live acceptance scenarios in `SYSTEM_TEST_REPORT.md` against the project.
