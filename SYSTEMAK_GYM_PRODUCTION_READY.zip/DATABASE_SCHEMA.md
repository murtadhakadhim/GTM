# SYSTEMAK GYM — Database Schema

The application extends the existing Supabase schema through ordered, additive migrations. Apply migrations 001–006 in order; do not reset the project.

## Existing records retained

| Table | Purpose |
|---|---|
| `trainees` | Member profile, current weight, coach assignment and linked Auth account. |
| `courses` | Program title, description, coach, flexible day count, archive state. |
| `course_days` | Ordered training days; no rest-day records are generated. |
| `exercises` | Independent exercise entries per training day, media references, repetition rounds and ordering. |
| `course_assignments` | One active course/version per trainee, enforced by the unique trainee relation. |
| `subscriptions` | Weekly/monthly membership history, start, expiry, and renewal records. |
| `gym_staff` | Admin/coach roles and display names. |

## Added structures

- `course_versions`: immutable JSON snapshots of courses, days, muscles and exercise rows.
- `exercise_library`, `exercise_tags`, `exercise_library_tags`: reusable definitions with multiple muscle/equipment/category tags and archive state.
- `course_day_muscles`: multiple muscle groups for a training day.
- `exercise_requests`: coach proposals pending admin approval.
- `trainee_weight_history`: weight measurements, including existing-profile baselines.
- `gym_audit_log`: insert/update/delete audit events for important operational tables.
- `trainee_program_history`: per-trainee program/version assignment timeline.

## Key migration changes

- Migration 004 makes course day counts flexible, adds coach links, library/tags, snapshots, weight history, audit logging, and tightened coach/media RLS.
- Migration 005 adds structured variable repetition rounds while preserving the existing repetition text and backfills current course assignments to snapshots.
- Migration 006 records program assignments per trainee and grants scoped read access to admins, assigned coaches, and the member themselves.

The existing private `exercise-media` objects and references are retained. New video and image uploads use the private `exercise-videos` and `exercise-images` buckets. Replaced media is intentionally retained because a historical assigned snapshot may still reference it.

## Security notes

- All new records are protected by RLS; admin/coach/member access differs by role and assignment.
- The member app uses phone + four-digit PIN through the existing Edge Functions; SMS is not part of this flow.
- Exercise storage remains private; playback uses time-limited signed URLs after Storage RLS authorization.
- `seed.sql` contains no fabricated member or course rows.

Remote migration application and RLS behavior still need confirmation in the intended Supabase project. Source files alone do not prove the remote schema matches this schema.
