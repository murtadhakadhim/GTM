# Deployment Checklist

## Supabase

- [ ] Apply migrations 001–006 in order after reviewing them for the intended project; do not reset the database.
- [ ] Confirm RLS is enabled and no broad all-authenticated policies remain.
- [ ] Confirm the existing `MEMBER_PIN_PEPPER` is configured. Do not rotate it; that invalidates PIN verifiers.
- [ ] Configure optional Turnstile secret if enabling CAPTCHA.
- [ ] Deploy `member-pin-login`, `set-member-pin`, and `invite-coach`.
- [ ] Confirm no duplicate trainee phone numbers before PIN provisioning.
- [ ] Set a four-digit PIN on a trainee and validate member login (no SMS/OTP).
- [ ] Create Admin/Coach Auth accounts and insert their `gym_staff` roles.
- [ ] Set each trainee's and course's `coach_user_id` before enabling coach access.
- [ ] Verify assigned coaches cannot query other coaches' trainees, programs or media.
- [ ] Confirm `exercise-media`, `exercise-videos`, and `exercise-images` are private with policies.
- [ ] Test member isolation with two trainees.

## Cloudflare Pages

- [ ] Push the clean project (no `.env`, `node_modules`, or scratch files) to GitHub.
- [ ] Create Pages project from Git; build `npm run build`, output `dist`.
- [ ] Set production build variables for Supabase URL, publishable/anon key, and optional Turnstile site key.
- [ ] Deploy and check both `/` and `/member`.
- [ ] Add the deployed hostname to Supabase Auth site URL/redirect allow-list.
- [ ] Run the live workflow in `SYSTEM_TEST_REPORT.md`; record outcomes before calling the deployment complete.

## Release archive

- [ ] Confirm `outputs/SYSTEMAK_GYM_PRODUCTION_READY.zip` excludes secrets, node_modules, work caches, and output duplication.
- [ ] Confirm archive includes source, migrations, Edge Functions, docs, Cloudflare SPA fallback, package lock, and verified `dist`.
