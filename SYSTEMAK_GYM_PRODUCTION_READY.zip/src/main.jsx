import React, { useCallback, useEffect, useMemo, useState } from 'react';
import { createRoot } from 'react-dom/client';
import { anon, supabase, url } from './supabase.js';
import './styles.css';
import { MemberApp, normalizeIraqiPhone } from './member.jsx';

const menu = [
  ['dashboard', 'لوحة التحكم', '▦'], ['trainees', 'المتدربون', '♟'],
  ['courses', 'الكورسات والبرامج', 'Ⅱ'], ['exercises', 'محرر البرامج', '⌁'],
  ['library', 'مكتبة التمارين', '▧'], ['coaches', 'الكباتن', '♟'],
  ['requests', 'طلبات التمارين', '✉'], ['subscriptions', 'الاشتراكات', '▤'],
  ['reports', 'التقارير', '▥'], ['activity', 'سجل العمليات', '≡'], ['settings', 'الإعدادات', '⚙'],
];
const today = () => new Date().toISOString().slice(0, 10);
const dateLabel = (value) => value ? new Date(`${value}T12:00:00`).toLocaleDateString('en-CA') : '—';
const addPlanPeriod = (date, plan) => { const value=new Date(`${date}T12:00:00`); if(plan==='weekly')value.setDate(value.getDate()+7);else{const day=value.getDate();value.setDate(1);value.setMonth(value.getMonth()+1);const last=new Date(value.getFullYear(),value.getMonth()+1,0).getDate();value.setDate(Math.min(day,last));}return value.toISOString().slice(0,10); };
const trainingDayName = (index) => `اليوم ${['الأول','الثاني','الثالث','الرابع','الخامس','السادس','السابع','الثامن','التاسع','العاشر'][index] || index + 1}`;
const toastError = (error) => alert(error?.message || 'حدث خطأ. حاول مرة أخرى.');

function App() {
  const [session, setSession] = useState(null);
  const [configured, setConfigured] = useState(Boolean(supabase));
  const [page, setPage] = useState('dashboard');
  const [staff, setStaff] = useState(null);
  const [data, setData] = useState({ trainees: [], courses: [], days: [], exercises: [], assignments: [], subscriptions: [], library: [], tags: [], libraryTags: [], dayMuscles: [], requests: [], weightHistory: [], programHistory: [], versions: [], staff: [], audit: [] });
  const [loading, setLoading] = useState(Boolean(supabase));
  const [query, setQuery] = useState('');
  const [modal, setModal] = useState(null);
  const [selectedCourse, setSelectedCourse] = useState('');
  const [selectedDay, setSelectedDay] = useState('');
  const [busy, setBusy] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(null);
  const [notice, setNotice] = useState('');

  const refresh = useCallback(async () => {
    if (!supabase || !session) return;
    setLoading(true);
    const staffResult = await supabase.from('gym_staff').select('user_id,role,display_name').eq('user_id', session.user.id).maybeSingle();
    if (staffResult.error || !staffResult.data) { setStaff(null); setLoading(false); if (staffResult.error) toastError(staffResult.error); return; }
    const access = staffResult.data;
    setStaff(access);
    const queries = [
      ['trainees','trainees'], ['courses','courses'], ['days','course_days'], ['exercises','exercises'],
      ['assignments','course_assignments'], ['subscriptions','subscriptions'], ['library','exercise_library'],
      ['tags','exercise_tags'], ['libraryTags','exercise_library_tags'], ['dayMuscles','course_day_muscles'], ['requests','exercise_requests'],
      ['weightHistory','trainee_weight_history'], ['programHistory','trainee_program_history'], ['versions','course_versions'],
    ];
    if (access.role === 'admin') queries.push(['staff','gym_staff'], ['audit','gym_audit_log']);
    const results = await Promise.all(queries.map(([key,table]) => {
      const query=supabase.from(table).select(table==='course_versions'?'id,course_id,version_number,created_at':'*');
      return table==='exercise_library_tags'||table==='course_day_muscles'?query:query.order(table==='gym_audit_log'?'occurred_at':table==='trainee_program_history'?'assigned_at':'created_at',{ascending:false});
    }));
    const failed = results.find((r) => r.error);
    if (failed) toastError(failed.error);
    const next = { trainees: [], courses: [], days: [], exercises: [], assignments: [], subscriptions: [], library: [], tags: [], libraryTags: [], dayMuscles: [], requests: [], weightHistory: [], programHistory: [], versions: [], staff: [], audit: [] };
    queries.forEach(([key], index) => { next[key] = results[index].data || []; });
    setData(next);
    setLoading(false);
  }, [session]);

  useEffect(() => {
    if (!supabase) return;
    supabase.auth.getSession().then(({ data: { session: current } }) => { setSession(current); setLoading(false); });
    const { data: { subscription } } = supabase.auth.onAuthStateChange((_event, current) => setSession(current));
    return () => subscription.unsubscribe();
  }, []);
  useEffect(() => { refresh(); }, [refresh]);
  useEffect(() => {
    if (!notice) return;
    const timer = setTimeout(() => setNotice(''), 2600);
    return () => clearTimeout(timer);
  }, [notice]);

  const run = async (action, success = 'تم الحفظ بنجاح') => {
    setBusy(true);
    try { await action(); await refresh(); setModal(null); setNotice(success); return true; }
    catch (e) { toastError(e); return false; }
    finally { setBusy(false); setUploadProgress(null); }
  };

  const saveTrainee = (form, record) => run(async () => {
    if (!record && form.plan_type && (!form.membership_start || !form.membership_end)) throw new Error('أكمل تاريخ بداية ونهاية الاشتراك، أو اختر «بدون اشتراك الآن».');
    const values = { full_name: form.full_name.trim(), phone: form.phone.trim(), age: Number(form.age), weight: Number(form.weight), height: Number(form.height) };
    if (record && normalizeIraqiPhone(record.phone) !== normalizeIraqiPhone(values.phone)) values.auth_user_id = null;
    const result = record
      ? await supabase.from('trainees').update(values).eq('id', record.id).select('id').single()
      : await supabase.from('trainees').insert(values).select('id').single();
    if (result.error) throw result.error;
    if (form.member_pin) {
      const { error } = await supabase.functions.invoke('set-member-pin', { body: { traineeId: result.data.id, pin: form.member_pin } });
      if (error) throw new Error(error.context?.status === 403 ? 'تعيين الرمز السري متاح لمدير النظام فقط.' : 'تعذر حفظ رمز الدخول. تحقق من نشر وظيفة set-member-pin ثم حاول مجدداً.');
    }
    if (!record) {
      if (form.coach_user_id) { const {error}=await supabase.from('trainees').update({coach_user_id:form.coach_user_id}).eq('id',result.data.id); if(error)throw error; }
      if (form.course_id) {
        const version=await supabase.from('course_versions').select('id').eq('course_id',form.course_id).order('version_number',{ascending:false}).limit(1).maybeSingle(); if(version.error)throw version.error;
        let courseVersionId=version.data?.id; if(!courseVersionId){const created=await supabase.rpc('create_course_version',{p_course_id:form.course_id});if(created.error)throw created.error;courseVersionId=created.data;}
        const {error}=await supabase.from('course_assignments').upsert({trainee_id:result.data.id,course_id:form.course_id,course_version_id:courseVersionId,start_date:form.program_start||today()},{onConflict:'trainee_id'}); if(error)throw error;
      }
      if (form.plan_type && form.membership_start && form.membership_end) { const {error}=await supabase.from('subscriptions').insert({trainee_id:result.data.id,plan_type:form.plan_type,start_date:form.membership_start,expires_at:form.membership_end}); if(error)throw error; }
    }
  }, record ? 'تم تحديث بيانات المتدرب' : 'تمت إضافة المتدرب');

  const deleteTrainee = (trainee) => {
    if (!confirm(`هل تريد حذف المتدرب «${trainee.full_name}»؟`)) return;
    run(async () => { const { error } = await supabase.from('trainees').delete().eq('id', trainee.id); if (error) throw error; }, 'تم حذف المتدرب');
  };

  const saveCourse = (form, original) => run(async () => {
    const count = Math.max(1, Math.min(30, Number(form.training_days)));
    const values = { name: form.name.trim(), description: form.description.trim(), coach_name: form.coach_name.trim() || (staff.role==='coach'?staff.display_name||session.user.email:''), training_days: count, coach_user_id: form.coach_user_id || (staff.role==='coach'?session.user.id:null) };
    let course;
    if (original) {
      const existing = data.days.filter((day) => day.course_id === original.id);
      if (count < existing.length && !confirm(`تقليل الأيام سيزيل ${existing.length-count} يوم/أيام من النسخة الحالية. النسخ السابقة المعيّنة ستبقى محفوظة. هل تريد المتابعة؟`)) throw new Error('تم إلغاء تعديل عدد الأيام.');
      const { data: saved, error } = await supabase.from('courses').update(values).eq('id', original.id).select().single();
      if (error) throw error; course = saved;
      
      if (count < existing.length) { const { error: deleteError } = await supabase.from('course_days').delete().eq('course_id', course.id).gt('day_number', count); if (deleteError) throw deleteError; }
      if (count > existing.length) { const extra = Array.from({length:count-existing.length},(_,n)=>({course_id:course.id,day_number:existing.length+n+1,name:trainingDayName(existing.length+n)})); const {error: addError}=await supabase.from('course_days').insert(extra); if(addError)throw addError; }
    } else {
      const { data: created, error } = await supabase.from('courses').insert(values).select().single();
      if (error) throw error; course = created;
      const days = Array.from({ length: count }, (_, i) => ({ course_id: course.id, day_number: i + 1, name: trainingDayName(i) }));
      const result = await supabase.from('course_days').insert(days);
      if (result.error) throw result.error;
    }
    const snapshot = await supabase.rpc('create_course_version', { p_course_id: course.id });
    if (snapshot.error) throw snapshot.error;
  }, original ? 'تم حفظ نسخة جديدة من الكورس' : 'تم إنشاء الكورس وأيام التدريب');

  const archiveCourse = (course) => {
    const restore=Boolean(course.archived_at);if(!confirm(restore?`استعادة كورس «${course.name}»؟`:`أرشفة كورس «${course.name}»؟ سيبقى محفوظاً للبرامج والاشتراكات السابقة.`))return;
    run(async () => { const { error } = await supabase.from('courses').update({archived_at:restore?null:new Date().toISOString()}).eq('id', course.id); if (error) throw error; }, restore?'تمت استعادة الكورس':'تمت أرشفة الكورس');
  };

  const saveCourseDay = (day, patch) => run(async () => {
    const { error } = await supabase.from('course_days').update(patch).eq('id', day.id);
    if (error) throw error;
    const snapshot = await supabase.rpc('create_course_version', { p_course_id: day.course_id });
    if (snapshot.error) throw snapshot.error;
  }, 'تم حفظ اليوم في نسخة جديدة من الكورس');

  const snapshotCourseDay = async (dayId) => {
    const day = await supabase.from('course_days').select('course_id').eq('id', dayId).single();
    if (day.error) throw day.error;
    const version = await supabase.rpc('create_course_version', { p_course_id: day.data.course_id });
    if (version.error) throw version.error;
  };

  const saveDayMuscles = (day, names) => run(async () => {
    const {error:removeError}=await supabase.from('course_day_muscles').delete().eq('course_day_id',day.id);if(removeError)throw removeError;
    for(const name of [...new Set(names.split(/[،,]/).map(value=>value.trim()).filter(Boolean))]){
      const tag=await supabase.from('exercise_tags').upsert({kind:'muscle',name},{onConflict:'kind,name'}).select('id').single();if(tag.error)throw tag.error;
      const link=await supabase.from('course_day_muscles').insert({course_day_id:day.id,tag_id:tag.data.id});if(link.error)throw link.error;
    }
    const snapshot=await supabase.rpc('create_course_version',{p_course_id:day.course_id});if(snapshot.error)throw snapshot.error;
  },'تم حفظ عضلات اليوم في نسخة جديدة');

  const reorderDay = async (day, direction) => {
    const siblings = data.days.filter((d)=>d.course_id===day.course_id).sort((a,b)=>a.day_number-b.day_number);
    const index=siblings.findIndex((d)=>d.id===day.id); const other=siblings[index+direction]; if(!other)return;
    setBusy(true);
    const temp=1000+day.day_number;
    const first=await supabase.from('course_days').update({day_number:temp}).eq('id',day.id);
    const second=first.error?first:await supabase.from('course_days').update({day_number:day.day_number}).eq('id',other.id);
    const third=second.error?second:await supabase.from('course_days').update({day_number:other.day_number}).eq('id',day.id);
    if(first.error||second.error||third.error){toastError(first.error||second.error||third.error);setBusy(false);return;}
    const snapshot=await supabase.rpc('create_course_version',{p_course_id:day.course_id});
    if(snapshot.error)toastError(snapshot.error); else await refresh();
    setBusy(false);
  };

  const saveLibraryExercise = (form, original) => run(async () => {
    const bucketVideo=original?.video_bucket||'exercise-videos';
    const bucketImage=original?.image_bucket||'exercise-images';
    let videoPath=original?.video_path||null, imagePath=original?.image_path||null;
    let uploadedVideo=null, uploadedImage=null;
    let databaseSaved=false;
    try {
      if(form.video){videoPath=uploadedVideo=await uploadMedia(form.video,'videos','exercise-videos');}
      if(form.image){imagePath=uploadedImage=await uploadMedia(form.image,'images','exercise-images');}
      if(!videoPath)throw new Error('فيديو التمرين مطلوب');
      const values={name:form.name.trim(),video_path:videoPath,video_bucket:form.video?'exercise-videos':bucketVideo,image_path:imagePath,image_bucket:imagePath?(form.image?'exercise-images':bucketImage):null,notes:form.notes.trim(),created_by:session.user.id,archived_at:original?.archived_at||null,updated_at:new Date().toISOString()};
      let id;
      if(original){const {error}=await supabase.from('exercise_library').update(values).eq('id',original.id);if(error)throw error;id=original.id;}
      else {const {data:created,error}=await supabase.from('exercise_library').insert(values).select('id').single();if(error)throw error;id=created.id;}
      databaseSaved=true;
      const {error:clearError}=await supabase.from('exercise_library_tags').delete().eq('exercise_id',id);if(clearError)throw clearError;
      for(const [kind,raw] of [['muscle',form.muscles],['equipment',form.equipment],['category',form.categories]]){
        const names=[...new Set(String(raw||'').split(',').map((name)=>name.trim()).filter(Boolean))];
        for(const name of names){const tag=await supabase.from('exercise_tags').upsert({kind,name},{onConflict:'kind,name'}).select('id').single();if(tag.error)throw tag.error;const link=await supabase.from('exercise_library_tags').insert({exercise_id:id,tag_id:tag.data.id});if(link.error)throw link.error;}
      }
      // Keep replaced media: existing program snapshots may still reference it.
    } catch(error){if(databaseSaved)throw error;const cleanup=[];if(uploadedVideo)cleanup.push(supabase.storage.from('exercise-videos').remove([uploadedVideo]));if(uploadedImage)cleanup.push(supabase.storage.from('exercise-images').remove([uploadedImage]));await Promise.all(cleanup);throw error;}
  }, original ? 'تم تحديث التمرين في المكتبة' : 'تمت إضافة التمرين للمكتبة');

  const archiveLibraryExercise = (exercise) => run(async () => {
    const archived_at=exercise.archived_at?null:new Date().toISOString();
    const {error}=await supabase.from('exercise_library').update({archived_at,updated_at:new Date().toISOString()}).eq('id',exercise.id);
    if(error)throw error;
  }, exercise.archived_at?'تمت استعادة التمرين':'تمت أرشفة التمرين');

  const submitExerciseRequest = (form) => run(async () => {
    let videoPath=null,imagePath=null;
    try {
      videoPath=await uploadMedia(form.video,'videos','exercise-videos');
      if(form.image)imagePath=await uploadMedia(form.image,'images','exercise-images');
      const {error}=await supabase.from('exercise_requests').insert({submitted_by:session.user.id,name:form.name.trim(),video_path:videoPath,video_bucket:'exercise-videos',image_path:imagePath,image_bucket:imagePath?'exercise-images':null,notes:form.notes.trim(),muscle_tags:form.muscles,equipment_tags:form.equipment,category_tags:form.categories});
      if(error)throw error;
    }catch(error){const cleanup=[];if(videoPath)cleanup.push(supabase.storage.from('exercise-videos').remove([videoPath]));if(imagePath)cleanup.push(supabase.storage.from('exercise-images').remove([imagePath]));await Promise.all(cleanup);throw error;}
  },'تم إرسال اقتراح التمرين إلى المدير');

  const reviewExerciseRequest = (request, approve) => run(async () => {
    if(!approve){const review_note=prompt('سبب الرفض (اختياري):','');if(review_note===null)return;const {error}=await supabase.from('exercise_requests').update({status:'rejected',review_note,reviewed_by:session.user.id,reviewed_at:new Date().toISOString()}).eq('id',request.id);if(error)throw error;return;}
    const {data:library,error}=await supabase.from('exercise_library').insert({name:request.name,video_path:request.video_path,video_bucket:request.video_bucket,image_path:request.image_path,image_bucket:request.image_bucket,notes:request.notes,created_by:session.user.id}).select('id').single();if(error)throw error;
    const tags=[...(request.muscle_tags||[]).map((name)=>({kind:'muscle',name})),...(request.equipment_tags||[]).map((name)=>({kind:'equipment',name})),...(request.category_tags||[]).map((name)=>({kind:'category',name}))];
    for(const tag of tags){const saved=await supabase.from('exercise_tags').upsert(tag,{onConflict:'kind,name'}).select('id').single();if(saved.error)throw saved.error;const link=await supabase.from('exercise_library_tags').insert({exercise_id:library.id,tag_id:saved.data.id});if(link.error)throw link.error;}
    const {error:updateError}=await supabase.from('exercise_requests').update({status:'approved',reviewed_by:session.user.id,reviewed_at:new Date().toISOString(),library_exercise_id:library.id}).eq('id',request.id);if(updateError)throw updateError;
  },approve?'تمت الموافقة وإضافة التمرين إلى المكتبة':'تم رفض الاقتراح');

  const addLibraryExerciseToDay = async (exercise) => {
    if(!selectedDay){toastError(new Error('اختر الكورس واليوم أولاً من محرر البرامج.'));return;}
    const repetitions=prompt(`التكرارات لتمرين «${exercise.name}»؟`,'12، 10، 8، 8');if(repetitions===null)return;
    setBusy(true);
    const sets=repetitions.split(/[،,]/).map((value)=>value.trim()).filter(Boolean);
    const {error}=await supabase.from('exercises').insert({course_day_id:selectedDay,library_exercise_id:exercise.id,name:exercise.name,repetitions:sets.join('، '),sets_reps:sets,video_path:exercise.video_path,video_bucket:exercise.video_bucket,image_path:exercise.image_path,image_bucket:exercise.image_bucket,notes:exercise.notes,sort_order:data.exercises.filter((item)=>item.course_day_id===selectedDay).length});
    if(error)toastError(error);else{try{await snapshotCourseDay(selectedDay);await refresh();setNotice('أُضيفت نسخة مستقلة من تمرين المكتبة إلى اليوم التدريبي');}catch(snapshotError){toastError(snapshotError);}}
    setBusy(false);
  };

  const uploadMedia = async (file, folder, bucket) => {
    if (!file) return null;
    const allowed = folder === 'videos' ? ['video/mp4','video/quicktime','video/webm','video/x-msvideo'] : ['image/jpeg','image/png','image/webp'];
    const limit = folder === 'videos' ? 200 * 1024 * 1024 : 10 * 1024 * 1024;
    if (!allowed.includes(file.type)) throw new Error(folder === 'videos' ? 'نوع الفيديو غير مدعوم. استخدم MP4 أو MOV أو WebM أو AVI.' : 'نوع الصورة غير مدعوم. استخدم JPG أو PNG أو WebP.');
    if (file.size > limit) throw new Error(folder === 'videos' ? 'الحد الأقصى لحجم الفيديو 200 ميغابايت.' : 'الحد الأقصى لحجم الصورة 10 ميغابايت.');
    const extension = file.name.split('.').pop().toLowerCase().replace(/[^a-z0-9]/g, '') || 'bin';
    const { data: { session: activeSession } } = await supabase.auth.getSession();
    if (!activeSession) throw new Error('انتهت جلسة الدخول. سجّل الدخول مجدداً.');
    const path = `${folder}/${activeSession.user.id}/${crypto.randomUUID()}.${extension}`;
    await new Promise((resolve, reject) => {
      const request = new XMLHttpRequest();
      const encodedPath = path.split('/').map(encodeURIComponent).join('/');
      request.open('POST', `${url}/storage/v1/object/${bucket}/${encodedPath}`);
      request.setRequestHeader('apikey', anon);
      request.setRequestHeader('Authorization', `Bearer ${activeSession.access_token}`);
      request.setRequestHeader('Content-Type', file.type || 'application/octet-stream');
      request.setRequestHeader('x-upsert', 'false');
      request.upload.onprogress = (event) => { if (event.lengthComputable) setUploadProgress(Math.round((event.loaded / event.total) * 100)); };
      request.onload = () => request.status >= 200 && request.status < 300 ? resolve() : reject(new Error('فشل رفع الملف: ' + (request.responseText || request.statusText)));
      request.onerror = () => reject(new Error('انقطع الاتصال أثناء رفع الملف'));
      request.onabort = () => reject(new Error('تم إلغاء رفع الملف'));
      setUploadProgress(0);
      request.send(file);
    });
    return path;
  };

  const saveExercise = (form, original) => run(async () => {
    let videoPath = original?.video_path || null;
    let imagePath = original?.image_path || null;
    let videoBucket = original?.video_bucket || 'exercise-media';
    let imageBucket = original?.image_bucket || (original?.image_path ? 'exercise-media' : null);
    let uploadedVideo = null;
    let uploadedImage = null;
    let databaseSaved = false;
    try {
    if (form.video) { videoBucket = 'exercise-videos'; videoPath = uploadedVideo = await uploadMedia(form.video, 'videos', videoBucket); }
    if (form.image) { imageBucket = 'exercise-images'; imagePath = uploadedImage = await uploadMedia(form.image, 'images', imageBucket); }
    if (!videoPath) throw new Error('فيديو التمرين مطلوب');
    const sets = (form.sets_reps || []).map((value) => String(value).trim()).filter(Boolean);
    if (!sets.length) throw new Error('أضف تكراراً واحداً على الأقل');
    const values = { course_day_id: selectedDay || original?.course_day_id, name: form.name.trim(), repetitions: sets.join('، '), sets_reps: sets, notes: form.notes.trim(), video_path: videoPath, video_bucket: videoBucket, image_path: imagePath, image_bucket: imageBucket, sort_order: original?.sort_order ?? data.exercises.filter((e) => e.course_day_id === (selectedDay || original?.course_day_id)).length };
    const result = original ? await supabase.from('exercises').update(values).eq('id', original.id) : await supabase.from('exercises').insert(values);
    if (result.error) throw result.error;
    databaseSaved = true;
    await snapshotCourseDay(values.course_day_id);
    // Keep replaced files: immutable course versions may still refer to them.
    } catch (error) {
      const cleanup = [];
      if (databaseSaved) throw error;
      if (uploadedVideo) cleanup.push(supabase.storage.from(videoBucket).remove([uploadedVideo]));
      if (uploadedImage) cleanup.push(supabase.storage.from(imageBucket).remove([uploadedImage]));
      await Promise.all(cleanup);
      throw error;
    }
  }, original ? 'تم تحديث التمرين' : 'تمت إضافة التمرين');

  const deleteExercise = (exercise) => {
    if (!confirm(`حذف تمرين «${exercise.name}»؟`)) return;
    run(async () => {
      const { error } = await supabase.from('exercises').delete().eq('id', exercise.id); if (error) throw error;
      // Keep media objects: assigned course snapshots may still require them.
      await snapshotCourseDay(exercise.course_day_id);
    }, 'تم حذف التمرين');
  };

  const moveExercise = async (exercise, direction) => {
    const list = data.exercises.filter((e) => e.course_day_id === exercise.course_day_id).sort((a, b) => a.sort_order - b.sort_order);
    const index = list.findIndex((e) => e.id === exercise.id); const swap = list[index + direction];
    if (!swap) return;
    setBusy(true);
    const a = await supabase.from('exercises').update({ sort_order: swap.sort_order }).eq('id', exercise.id);
    const b = await supabase.from('exercises').update({ sort_order: exercise.sort_order }).eq('id', swap.id);
    setBusy(false);
    if (a.error || b.error) toastError(a.error || b.error); else { try { await snapshotCourseDay(exercise.course_day_id); await refresh(); } catch (error) { toastError(error); } }
  };

  const reorderExercises = async (sourceId, targetId) => {
    const target=data.exercises.find(e=>e.id===targetId); const source=data.exercises.find(e=>e.id===sourceId); if(!target||!source||source.course_day_id!==target.course_day_id||sourceId===targetId)return;
    const list=data.exercises.filter(e=>e.course_day_id===source.course_day_id).sort((a,b)=>a.sort_order-b.sort_order);const from=list.findIndex(e=>e.id===sourceId);const to=list.findIndex(e=>e.id===targetId);const [item]=list.splice(from,1);list.splice(to,0,item);setBusy(true);
    const results=await Promise.all(list.map((exercise,index)=>supabase.from('exercises').update({sort_order:index}).eq('id',exercise.id)));const failed=results.find(result=>result.error);
    if(failed)toastError(failed.error);else{try{await snapshotCourseDay(source.course_day_id);await refresh();setNotice('تم حفظ ترتيب التمارين');}catch(error){toastError(error);}}setBusy(false);
  };

  const saveAssignment = (form, existing) => run(async () => {
    const version = await supabase.from('course_versions').select('id').eq('course_id', form.course_id).order('version_number', { ascending: false }).limit(1).maybeSingle();
    if (version.error) throw version.error;
    let versionId = version.data?.id || null;
    if (!versionId) { const created = await supabase.rpc('create_course_version', { p_course_id: form.course_id }); if (created.error) throw created.error; versionId = created.data; }
    const values = { trainee_id: form.trainee_id, course_id: form.course_id, course_version_id: versionId, start_date: form.start_date };
    const result = existing ? await supabase.from('course_assignments').update(values).eq('id', existing.id) : await supabase.from('course_assignments').upsert(values, { onConflict: 'trainee_id' });
    if (result.error) throw result.error;
  }, 'تم حفظ تعيين الكورس');

  const saveSubscription = (form) => run(async () => {
    const values = { trainee_id: form.trainee_id, plan_type: form.plan_type, start_date: form.start_date, expires_at: form.expires_at };
    const result = await supabase.from('subscriptions').insert(values);
    if (result.error) throw result.error;
  }, 'تم تسجيل الاشتراك مع حفظ السجل السابق');

  const assignTraineeCoach = (traineeId, coachUserId) => run(async()=>{const {error}=await supabase.from('trainees').update({coach_user_id:coachUserId||null}).eq('id',traineeId);if(error)throw error;},'تم تحديث كابتن المتدرّب');
  const createCoach = (form) => run(async()=>{const {error}=await supabase.functions.invoke('invite-coach',{body:form});if(error)throw new Error(error.context?.status===403?'إنشاء حساب كابتن متاح لمدير النظام فقط.':'تعذر إنشاء الحساب. تحقق من نشر invite-coach وأن البريد غير مستخدم.');},'تم إنشاء حساب الكابتن');
  const recordWeight = (trainee) => { const value=prompt(`الوزن الجديد للمتدرب ${trainee.full_name} بالكيلوغرام:`,String(trainee.weight)); if(value===null)return; const weight=Number(value); if(!Number.isFinite(weight)||weight<=0){toastError(new Error('أدخل وزناً صحيحاً أكبر من صفر.'));return;} run(async()=>{const {error}=await supabase.from('trainees').update({weight}).eq('id',trainee.id);if(error)throw error;},'تم تسجيل الوزن في سجل المتدرب'); };

  const filtered = useMemo(() => data.trainees.filter((t) => `${t.full_name} ${t.phone}`.includes(query.trim())), [data.trainees, query]);
  const visibleMenu = staff?.role === 'admin' ? menu : menu.filter(([id]) => ['dashboard','trainees','courses','exercises','library','requests'].includes(id));

  if (!configured) return <Setup />;
  if (!session) return <Login onLogin={setSession} loading={loading} />;
  if (!staff && loading) return <div className="loading"><i/> جارٍ التحقق من صلاحيات الحساب...</div>;
  if (!staff) return <div className="auth-wrap"><section className="auth-card"><Brand/><h1>الحساب غير مفعّل كموظف</h1><p>اطلب من مدير النادي تفعيل حسابك كمدير أو كابتن.</p><button className="btn ghost full" onClick={()=>supabase.auth.signOut()}>تسجيل الخروج</button></section></div>;

  return <div className="app-shell">
    <aside className="sidebar">
      <div className="brand"><img src="/systemak-logo.png" alt="SYSTEMAK GYM"/><strong>SYSTEMAK <b>GYM</b></strong><span>NASER AL-ESAWY</span><small>نصر العيساوي</small></div>
      <nav>{visibleMenu.map(([id, label, icon]) => <button key={id} className={page === id ? 'nav-item active' : 'nav-item'} onClick={() => setPage(id)}><span>{icon}</span>{label}</button>)}</nav>
      <div className="account"><span className="avatar">{staff.role==='admin'?'م':'ك'}</span><div><b>{staff.display_name|| (staff.role==='admin'?'مدير النظام':'كابتن')}</b><small>{session.user.email}</small></div></div>
      <button className="logout" onClick={() => supabase.auth.signOut()}>↪ تسجيل الخروج</button>
    </aside>
    <main className="main-panel">
      <header className="topbar"><div><span className="eyebrow">SYSTEMAK GYM</span><h1>{visibleMenu.find((m) => m[0] === page)?.[1]||'لوحة التحكم'}</h1></div><div className="top-tools"><input aria-label="بحث المتدربين" placeholder="البحث باسم المتدرب أو رقم الهاتف..." value={query} onChange={(e) => setQuery(e.target.value)}/><span className="search-icon">⌕</span><button className="icon-btn" title="تحديث البيانات" onClick={refresh}>↻</button></div></header>
      {loading ? <div className="loading"><i/> جارٍ تحميل البيانات...</div> : <>
        {page === 'dashboard' && <Dashboard role={staff.role} data={data} filtered={filtered} onPage={setPage} onAdd={() => setModal({ type: 'trainee' })} onDetails={(t) => setModal({ type: 'details', item: t })} onCourse={(course) => { setSelectedCourse(course.id); setPage('exercises'); }}/>} 
        {page === 'trainees' && <Trainees role={staff.role} data={data} trainees={filtered} onAdd={() => setModal({ type: 'trainee' })} onEdit={(t) => setModal({ type: 'trainee', item: t })} onDetails={(t) => setModal({ type: 'details', item: t })} onDelete={deleteTrainee} onAssign={(t) => setModal({ type: 'assignment', item: t, assignment: data.assignments.find((a) => a.trainee_id === t.id) })} />}
        {page === 'courses' && <Courses role={staff.role} data={data} onAdd={() => setModal({ type: 'course' })} onEdit={(course)=>setModal({type:'course',item:course})} onArchive={archiveCourse} onSaveDay={saveCourseDay} onSaveMuscles={saveDayMuscles} onMoveDay={reorderDay} busy={busy} onExercises={(c) => { setSelectedCourse(c.id); setSelectedDay(''); setPage('exercises'); }}/>} 
        {page === 'exercises' && <Exercises data={data} courseId={selectedCourse} setCourse={setSelectedCourse} dayId={selectedDay} setDay={setSelectedDay} onAdd={() => setModal({ type: 'exercise' })} onEdit={(e) => setModal({ type: 'exercise', item: e })} onDelete={deleteExercise} onMove={moveExercise} onReorder={reorderExercises} busy={busy}/>} 
        {page === 'library' && <ExerciseLibrary data={data} role={staff.role} busy={busy} selectedDay={selectedDay} onSave={saveLibraryExercise} onArchive={archiveLibraryExercise} onAddToDay={addLibraryExerciseToDay} onRequest={submitExerciseRequest}/>} 
        {page === 'coaches' && <Coaches data={data} busy={busy} onCreate={createCoach} onRefresh={refresh} onAssignTrainee={assignTraineeCoach} onEditCourse={(course)=>setModal({type:'course',item:course})}/>} 
        {page === 'requests' && <ExerciseRequests data={data} role={staff.role} onReview={reviewExerciseRequest}/>} 
        {page === 'subscriptions' && <Subscriptions data={data} onAdd={() => setModal({ type: 'subscription' })} onRenew={(s) => setModal({ type: 'subscription', item: s })}/>} 
        {page === 'reports' && <Reports data={data}/>} 
        {page === 'activity' && <ActivityLog rows={data.audit}/>} 
        {page === 'settings' && <Settings email={session.user.email}/>} 
      </>}
    </main>
    {modal && <Modal modal={modal} data={data} onClose={() => setModal(null)} busy={busy} uploadProgress={uploadProgress} onSaveTrainee={saveTrainee} onSaveCourse={saveCourse} onSaveExercise={saveExercise} onSaveAssignment={saveAssignment} onSaveSubscription={saveSubscription} onRecordWeight={recordWeight}/>}
    {notice && <div className="toast">✓ {notice}</div>}
  </div>;
}

function Setup() { return <div className="auth-wrap"><div className="auth-card"><Brand/><h1>إعداد الاتصال بقاعدة البيانات</h1><p>أنشئ ملف <code>.env</code> من <code>.env.example</code>، ثم أضف عنوان مشروع Supabase ومفتاح النشر. شغّل ملف الترحيل <code>supabase/migrations/001_gym.sql</code> في محرر SQL داخل مشروعك.</p><div className="setup-code">VITE_SUPABASE_URL<br/>VITE_SUPABASE_ANON_KEY</div><small>بعد الإعداد وإنشاء حساب المدير، حدّث الصفحة لتسجيل الدخول.</small></div></div> }
function Brand() { return <div className="auth-brand"><img src="/systemak-logo.png" alt="SYSTEMAK GYM"/><b>NASER AL-ESAWY</b><span>نصر العيساوي · SYSTEMAK GYM</span></div> }
function Login({ onLogin, loading }) { const [email, setEmail] = useState(''); const [password, setPassword] = useState(''); const [busy, setBusy] = useState(false); const submit = async (e) => { e.preventDefault(); setBusy(true); const { data, error } = await supabase.auth.signInWithPassword({ email, password }); setBusy(false); if (error) toastError(error); else onLogin(data.session); }; return <div className="auth-wrap"><form className="auth-card" onSubmit={submit}><Brand/><h1>تسجيل دخول المدير</h1><label>البريد الإلكتروني<input type="email" required autoComplete="username" value={email} onChange={(e) => setEmail(e.target.value)} /></label><label>كلمة المرور<input type="password" required autoComplete="current-password" value={password} onChange={(e) => setPassword(e.target.value)} /></label><button className="btn primary full" disabled={busy || loading}>{busy ? 'جارٍ الدخول...' : 'تسجيل الدخول'}</button><small>أنشئ حساب المدير من لوحة Supabase Authentication.</small></form></div> }

function Dashboard({ role, data, filtered, onPage, onAdd, onDetails, onCourse }) {
  const active = data.subscriptions.filter((s) => s.start_date <= today() && s.expires_at >= today()).length;
  const recent = [...data.trainees].slice(0, 5);
  return <div className="content"><section className="stats-grid"><Stat icon="♟" number={data.trainees.length} label="إجمالي المتدربين"/><Stat icon="Ⅱ" number={active} label="المتدربون النشطون"/><Stat icon="＋" number={data.subscriptions.filter((s) => s.start_date?.slice(0, 7) === today().slice(0, 7)).length} label="الاشتراكات الجديدة"/><Stat icon="⌛" number={data.subscriptions.filter((s) => s.expires_at < today()).length} label="الاشتراكات المنتهية"/></section>
    {role==='admin'&&<section className="notification-strip"><button onClick={()=>onPage('requests')}><b>{data.requests.filter(r=>r.status==='pending').length}</b><span>اقتراحات تمارين بانتظار المراجعة</span><i>←</i></button><button onClick={()=>onPage('subscriptions')}><b>{data.subscriptions.filter(s=>s.expires_at<=today()).length}</b><span>اشتراكات انتهت أو تنتهي اليوم</span><i>←</i></button></section>}
    <section className="panel"><div className="section-heading"><div><span className="accent-mark">♟</span><h2>قائمة المتدربين</h2></div>{role==='admin'&&<button className="btn primary" onClick={onAdd}>＋ إضافة متدرب</button>}</div><div className="table-scroll"><table><thead><tr><th>الاسم</th><th>رقم الهاتف</th><th>العمر</th><th>الوزن</th><th>الكورس</th><th>حالة الاشتراك</th><th>التفاصيل</th></tr></thead><tbody>{recent.map((t) => { const sub = data.subscriptions.filter((s) => s.trainee_id === t.id).sort((a,b) => b.expires_at.localeCompare(a.expires_at))[0]; const assignment = data.assignments.find((a) => a.trainee_id === t.id); return <tr key={t.id}><td className="name-cell"><span className="avatar">{t.full_name.slice(0,1)}</span>{t.full_name}</td><td dir="ltr">{t.phone}</td><td>{t.age}</td><td>{t.weight} كغم</td><td>{data.courses.find((c) => c.id === assignment?.course_id)?.name || '—'}</td><td><span className={sub?.expires_at >= today() ? 'pill' : 'pill muted'}>{sub ? sub.expires_at >= today() ? 'نشط' : 'منتهي' : 'غير مشترك'}</span></td><td><button className="icon-btn" onClick={() => onDetails(t)}>◉</button></td></tr> })}{!recent.length && <tr><td colSpan="7" className="empty">لا يوجد متدربون بعد. ابدأ بإضافة أول متدرب.</td></tr>}</tbody></table></div></section>
    <div className="lower-grid"><section className="panel quick-panel"><div className="section-heading"><div><span className="accent-mark">⚡</span><h2>إجراءات سريعة</h2></div></div><p>إدارة يومية سهلة وسريعة للنادي.</p><div className="quick-actions">{role==='admin'&&<button onClick={onAdd}><b>＋</b>إضافة متدرب جديد</button>}<button onClick={() => onPage('courses')}><b>▣</b>إدارة الكورسات</button>{role==='admin'&&<button onClick={() => onPage('subscriptions')}><b>▤</b>الاشتراكات والتجديد</button>}<button onClick={() => onPage('library')}><b>⌁</b>مكتبة التمارين</button></div></section><section className="panel quick-panel"><div className="section-heading"><div><span className="accent-mark">🏆</span><h2>إدارة الكورسات</h2></div><button className="btn ghost" onClick={() => onPage('courses')}>عرض الكل ←</button></div><p>تابع كورسات النادي وأيام التدريب.</p><div className="course-preview">{data.courses.slice(0,2).map((c) => <button key={c.id} className="preview-item" onClick={() => onCourse(c)}><span className="preview-icon">▣</span><span><b>{c.name}</b><small>{c.training_days} أيام تدريب · {c.coach_name || 'بدون مدرب'}</small></span><span className="arrow">←</span></button>)}{!data.courses.length && <span className="empty">لا توجد كورسات حتى الآن</span>}</div></section></div>
  </div>;
}
function Stat({ icon, number, label }) { return <article className="stat-card"><span className="stat-icon">{icon}</span><div><b>{number}</b><small>{label}</small></div></article> }

function ExerciseLibrary({data,role,busy,selectedDay,onSave,onArchive,onAddToDay,onRequest}){
  const [form,setForm]=useState(null);const [search,setSearch]=useState('');const [muscle,setMuscle]=useState('');const [equipment,setEquipment]=useState('');const [category,setCategory]=useState('');const [showArchived,setShowArchived]=useState(false);const [selectedIds,setSelectedIds]=useState([]);
  const namesFor=(exercise,kind)=>data.libraryTags.filter((link)=>link.exercise_id===exercise.id).map((link)=>data.tags.find((tag)=>tag.id===link.tag_id)).filter((tag)=>tag?.kind===kind).map((tag)=>tag.name);
  const usage=(id)=>data.exercises.filter((item)=>item.library_exercise_id===id).length;
  const visible=data.library.filter((exercise)=>Boolean(exercise.archived_at)===showArchived&&exercise.name.toLowerCase().includes(search.trim().toLowerCase())&&(!muscle||namesFor(exercise,'muscle').includes(muscle))&&(!equipment||namesFor(exercise,'equipment').includes(equipment))&&(!category||namesFor(exercise,'category').includes(category))).sort((a,b)=>usage(b.id)-usage(a.id));
  const save=async(event)=>{event.preventDefault();const f=new FormData(event.currentTarget);const read=(name)=>String(f.get(name)||'').split(/[،,]/).map((x)=>x.trim()).filter(Boolean);const values={name:f.get('name'),notes:f.get('notes'),muscles:read('muscles'),equipment:read('equipment'),categories:read('categories'),video:f.get('video')?.size?f.get('video'):null,image:f.get('image')?.size?f.get('image'):null};const saved=form.proposal?await onRequest(values):await onSave(values,form.exercise||null);if(saved)setForm(null);};
  return <div className="content"><section className="panel"><div className="section-heading"><div><span className="accent-mark">▧</span><div><h2>مكتبة التمارين المشتركة</h2><small>تمرين واحد يمكن ربطه بعدة عضلات وأجهزة وتصنيفات</small></div></div>{role==='admin'?<button className="btn primary" onClick={()=>setForm({})}>＋ تمرين للمكتبة</button>:<button className="btn primary" onClick={()=>setForm({proposal:true})}>＋ اقتراح تمرين</button>}</div><div className="library-filters"><input value={search} onChange={(e)=>setSearch(e.target.value)} placeholder="بحث باسم التمرين"/><select value={muscle} onChange={(e)=>setMuscle(e.target.value)}><option value="">كل العضلات</option>{data.tags.filter((t)=>t.kind==='muscle').map((t)=><option key={t.id} value={t.name}>{t.name}</option>)}</select><select value={equipment} onChange={(e)=>setEquipment(e.target.value)}><option value="">كل الأجهزة</option>{data.tags.filter((t)=>t.kind==='equipment').map((t)=><option key={t.id} value={t.name}>{t.name}</option>)}</select><select value={category} onChange={(e)=>setCategory(e.target.value)}><option value="">كل التصنيفات</option>{data.tags.filter((t)=>t.kind==='category').map((t)=><option key={t.id} value={t.name}>{t.name}</option>)}</select>{role==='admin'&&<label className="inline-check"><input type="checkbox" checked={showArchived} onChange={(e)=>setShowArchived(e.target.checked)}/> المؤرشفة</label>}</div>
    {form&&<form className="library-editor" onSubmit={save}><div className="section-heading"><b>{form.proposal?'إرسال اقتراح تمرين للمدير':form.exercise?'تعديل التمرين':'إضافة تعريف تمرين'}</b><button type="button" className="icon-btn" onClick={()=>setForm(null)}>×</button></div><div className="library-form-grid"><Field label="اسم التمرين"><input name="name" required defaultValue={form.exercise?.name||''} placeholder="مثال: ضغط الصدر بالدمبل"/></Field><Field label="العضلات (افصل بينها بفاصلة)"><input name="muscles" defaultValue={form.muscles||''} placeholder="الصدر، الترايسبس"/></Field><Field label="الأجهزة (افصل بينها بفاصلة)"><input name="equipment" defaultValue={form.equipment||''} placeholder="دمبل، مقعد"/></Field><Field label="التصنيفات (اختياري)"><input name="categories" defaultValue={form.categories||''} placeholder="قوة، دفع"/></Field><Field label="فيديو التمرين — مطلوب عند الإنشاء"><input name="video" type="file" accept="video/mp4,video/quicktime,video/webm,video/x-msvideo" required={!form.exercise}/></Field><Field label="صورة توضيحية (اختياري)"><input name="image" type="file" accept="image/jpeg,image/png,image/webp"/></Field><Field label="ملاحظات (اختياري)"><textarea name="notes" rows="2" defaultValue={form.exercise?.notes||''}/></Field></div><small className="hint">الفيديو خاص. الأنواع والحجم يتحقق منها النظام عند الرفع. التعديل لا يبدل محتوى البرامج القديمة.</small><div className="modal-actions"><button type="button" className="btn ghost" onClick={()=>setForm(null)}>إلغاء</button><button className="btn primary" disabled={busy}>{busy?'جارٍ الحفظ والرفع…':'حفظ'}</button></div></form>}
    {role==='admin'&&<div className="bulk-actions"><button className="btn primary" disabled={!selectedDay||!selectedIds.length||busy} onClick={async()=>{for(const exercise of visible.filter((item)=>selectedIds.includes(item.id)&&!item.archived_at))await onAddToDay(exercise);setSelectedIds([]);}}>إضافة المحدد إلى اليوم النشط ({selectedIds.length})</button>{!selectedDay&&<small>افتح محرر البرامج واختر الكورس واليوم أولاً، ثم عد إلى المكتبة.</small>}</div>}
    <div className="exercise-list">{visible.map((exercise)=>{const muscles=namesFor(exercise,'muscle'), devices=namesFor(exercise,'equipment'), categories=namesFor(exercise,'category');return <article className="exercise-row" key={exercise.id}>{role==='admin'&&!exercise.archived_at&&<input type="checkbox" aria-label={`اختيار ${exercise.name}`} checked={selectedIds.includes(exercise.id)} onChange={(e)=>setSelectedIds((current)=>e.target.checked?[...current,exercise.id]:current.filter((id)=>id!==exercise.id))}/>}<div className="exercise-thumb">{exercise.image_path?<SignedImage path={exercise.image_path} bucket={exercise.image_bucket||'exercise-images'}/>:<span>⌁</span>}</div><div className="exercise-info"><b>{exercise.name}</b><small>{[...muscles,...devices,...categories].join(' · ')||'بلا تصنيفات'}</small><small>{exercise.archived_at?'مؤرشف':`مستخدم في ${data.exercises.filter(item=>item.library_exercise_id===exercise.id).length} برنامج · فيديو متاح`}</small></div><div className="actions"><button className="btn ghost" onClick={()=>openVideo(exercise.video_path,exercise.video_bucket||'exercise-videos')}>معاينة الفيديو</button>{role==='admin'&&!exercise.archived_at&&<button className="btn ghost" disabled={!selectedDay||busy} title={!selectedDay?'اختر يوماً من محرر البرامج أولاً':''} onClick={()=>onAddToDay(exercise)}>إضافة لليوم</button>}{role==='admin'&&<><button className="icon-btn" onClick={()=>setForm({exercise,muscles:muscles.join('، '),equipment:devices.join('، '),categories:categories.join('، ')})} title="تعديل">✎</button><button className="btn ghost" onClick={()=>onArchive(exercise)}>{exercise.archived_at?'استعادة':'أرشفة'}</button></>}</div></article>})}{!visible.length&&<div className="empty">لا توجد تمارين مطابقة.</div>}</div></section></div>
}

function ExerciseRequests({data,role,onReview}){const rows=role==='admin'?data.requests:data.requests.filter((r)=>r.submitted_by);return <div className="content"><section className="panel"><div className="section-heading"><div><span className="accent-mark">✉</span><div><h2>{role==='admin'?'طلبات التمارين':'اقتراحاتي للتمارين'}</h2><small>لا ينضم المقترح إلى المكتبة إلا بعد موافقة المدير</small></div></div></div><div className="exercise-list">{rows.map((request)=><article className="exercise-row" key={request.id}><span className="exercise-thumb">▶</span><div className="exercise-info"><b>{request.name}</b><small>{[...(request.muscle_tags||[]),...(request.equipment_tags||[]),...(request.category_tags||[])].join(' · ')}</small><small>{request.status==='pending'?'بانتظار المراجعة':request.status==='approved'?'تمت الموافقة':'مرفوض'} {request.review_note&&`· ${request.review_note}`}</small></div><button className="btn ghost" onClick={()=>openVideo(request.video_path,request.video_bucket)}>معاينة الفيديو</button>{role==='admin'&&request.status==='pending'&&<div className="actions"><button className="btn primary" onClick={()=>onReview(request,true)}>موافقة</button><button className="btn ghost" onClick={()=>onReview(request,false)}>رفض</button></div>}</article>)}{!rows.length&&<div className="empty">لا توجد طلبات.</div>}</div></section></div>}

function CoachesLegacy({data,onRefresh,onAssignTrainee,onEditCourse}){return null}

function Coaches({data,busy,onCreate,onRefresh,onAssignTrainee,onEditCourse}){
  const [creating,setCreating]=useState(false);const coaches=data.staff.filter((s)=>s.role==='coach');
  const submit=async(event)=>{event.preventDefault();const f=new FormData(event.currentTarget);await onCreate({name:f.get('name'),email:f.get('email'),password:f.get('password')});event.currentTarget.reset();setCreating(false);};
  return <div className="content"><section className="panel"><div className="section-heading"><div><span className="accent-mark">♟</span><div><h2>إدارة الكباتن</h2><small>صلاحية كل كابتن مرتبطة بمتدربيه وكورساتِه</small></div></div><div className="actions"><button className="btn primary" onClick={()=>setCreating((v)=>!v)}>＋ إنشاء حساب كابتن</button><button className="btn ghost" onClick={onRefresh}>تحديث</button></div></div>
    {creating&&<form className="library-editor" onSubmit={submit}><div className="library-form-grid"><Field label="اسم الكابتن"><input name="name" required minLength="2" maxLength="100"/></Field><Field label="البريد الإلكتروني"><input name="email" type="email" required autoComplete="off"/></Field><Field label="كلمة مرور أولية (12 حرفاً على الأقل)"><input name="password" type="password" required minLength="12" autoComplete="new-password"/></Field></div><small className="hint">سلّم كلمة المرور للكابتن بقناة خاصة، واطلب منه تغييرها بعد أول دخول.</small><div className="modal-actions"><button type="button" className="btn ghost" onClick={()=>setCreating(false)}>إلغاء</button><button className="btn primary" disabled={busy}>{busy?'جارٍ إنشاء الحساب…':'إنشاء الحساب'}</button></div></form>}
    <div className="table-scroll"><table><thead><tr><th>اسم الكابتن</th><th>معرّف الحساب</th><th>المتدرّبون</th><th>الكورسات</th></tr></thead><tbody>{coaches.map((coach)=><tr key={coach.user_id}><td>{coach.display_name||'—'}</td><td dir="ltr">{coach.user_id}</td><td>{data.trainees.filter((t)=>t.coach_user_id===coach.user_id).length}</td><td>{data.courses.filter((c)=>c.coach_user_id===coach.user_id).length}</td></tr>)}{!coaches.length&&<tr><td colSpan="4" className="empty">لا توجد حسابات كابتن حتى الآن.</td></tr>}</tbody></table></div></section>
    <section className="panel"><div className="section-heading"><h2>تعيين الكابتن للمتدرّبين</h2></div><div className="table-scroll"><table><thead><tr><th>المتدرّب</th><th>الهاتف</th><th>الكابتن</th></tr></thead><tbody>{data.trainees.map((t)=><tr key={t.id}><td>{t.full_name}</td><td dir="ltr">{t.phone}</td><td><select value={t.coach_user_id||''} onChange={(e)=>onAssignTrainee(t.id,e.target.value)}><option value="">غير مسند</option>{coaches.map(c=><option key={c.user_id} value={c.user_id}>{c.display_name||c.user_id}</option>)}</select></td></tr>)}</tbody></table></div></section>
    <section className="panel"><div className="section-heading"><h2>تعيين الكابتن للكورسات</h2></div><div className="table-scroll"><table><thead><tr><th>الكورس</th><th>الكابتن الحالي</th><th>الإجراء</th></tr></thead><tbody>{data.courses.map((course)=><tr key={course.id}><td>{course.name}</td><td>{coaches.find(c=>c.user_id===course.coach_user_id)?.display_name||'غير مسند'}</td><td><button className="btn ghost" onClick={()=>onEditCourse(course)}>تعديل الإسناد</button></td></tr>)}</tbody></table></div></section></div>
}

function Reports({data}){const now=today();const [from,setFrom]=useState(`${now.slice(0,4)}-01-01`);const [to,setTo]=useState(now);const [coach,setCoach]=useState('');const [status,setStatus]=useState('all');const period=s=>s>=from&&s<=to;const coaches=data.staff.filter(s=>s.role==='coach');const trainees=data.trainees.filter(t=>(!coach||t.coach_user_id===coach));const subscriptions=data.subscriptions.filter(s=>period(s.start_date)&&(!coach||data.trainees.find(t=>t.id===s.trainee_id)?.coach_user_id===coach));const active=subscriptions.filter(s=>s.start_date<=now&&s.expires_at>=now);const expired=subscriptions.filter(s=>s.expires_at<now);const filteredSubscriptions=subscriptions.filter(s=>status==='all'||(status==='active'?s.start_date<=now&&s.expires_at>=now:s.expires_at<now));const due=data.subscriptions.filter(s=>s.expires_at<=now);const max=Math.max(1,data.courses.length,...coaches.map(c=>data.trainees.filter(t=>t.coach_user_id===c.user_id).length));const month=now.slice(0,7);const newTrainees=trainees.filter(t=>period(String(t.created_at||'').slice(0,10))).length;const renewals=data.subscriptions.filter(s=>String(s.created_at||'').slice(0,7)===month);return <div className="content"><section className="report-filters panel"><label>من<input type="date" value={from} onChange={e=>setFrom(e.target.value)}/></label><label>إلى<input type="date" value={to} onChange={e=>setTo(e.target.value)}/></label><label>الكابتن<select value={coach} onChange={e=>setCoach(e.target.value)}><option value="">كل الكباتن</option>{coaches.map(c=><option key={c.user_id} value={c.user_id}>{c.display_name||c.user_id}</option>)}</select></label><label>حالة الاشتراك<select value={status} onChange={e=>setStatus(e.target.value)}><option value="all">الكل</option><option value="active">نشط</option><option value="expired">منتهي</option></select></label></section><section className="stats-grid"><Stat icon="♟" number={trainees.length} label="إجمالي المتدربين"/><Stat icon="Ⅱ" number={active.length} label="اشتراكات نشطة"/><Stat icon="⌛" number={expired.length} label="اشتراكات منتهية"/><Stat icon="▣" number={data.courses.filter(c=>!c.archived_at).length} label="البرامج النشطة"/></section><div className="report-grid"><section className="panel"><div className="section-heading"><h2>المتدربون حسب الكابتن</h2></div>{coaches.map(c=>{const n=trainees.filter(t=>t.coach_user_id===c.user_id).length;return <div className="report-bar-row" key={c.user_id}><span>{c.display_name||c.user_id}</span><div><i style={{width:`${Math.round(n/max*100)}%`}}/></div><b>{n}</b></div>})}<div className="setting-row"><span>متدربون جدد في الفترة المحددة</span><b>{newTrainees}</b></div><div className="setting-row"><span>تجديدات هذا الشهر</span><b>{renewals.length}</b></div></section><section className="panel"><div className="section-heading"><h2>الاشتراكات حسب الحالة</h2></div><div className="report-bar-row"><span>نشطة</span><div><i style={{width:`${Math.round(active.length/Math.max(1,subscriptions.length)*100)}%`}}/></div><b>{active.length}</b></div><div className="report-bar-row"><span>منتهية</span><div><i style={{width:`${Math.round(expired.length/Math.max(1,subscriptions.length)*100)}%`}}/></div><b>{expired.length}</b></div><small className="hint">الاشتراكات التي تنتهي اليوم أو انتهت: {due.length}</small></section></div><section className="panel"><div className="section-heading"><h2>سجل الاشتراكات للفترة المحددة</h2></div><div className="table-scroll"><table><thead><tr><th>المتدرب</th><th>الكابتن</th><th>النوع</th><th>البداية</th><th>الانتهاء</th><th>الحالة</th></tr></thead><tbody>{filteredSubscriptions.map(s=>{const trainee=data.trainees.find(t=>t.id===s.trainee_id);const captain=coaches.find(c=>c.user_id===trainee?.coach_user_id);const isActive=s.start_date<=now&&s.expires_at>=now;return <tr key={s.id}><td>{trainee?.full_name||'—'}</td><td>{captain?.display_name||'—'}</td><td>{s.plan_type==='weekly'?'أسبوعي':'شهري'}</td><td>{dateLabel(s.start_date)}</td><td>{dateLabel(s.expires_at)}</td><td>{isActive?'نشط':'منتهي'}</td></tr>})}{!filteredSubscriptions.length&&<tr><td className="empty" colSpan="6">لا توجد نتائج في هذه الفترة.</td></tr>}</tbody></table></div></section></div>}

function ActivityLog({rows}){return <div className="content"><section className="panel"><div className="section-heading"><div><span className="accent-mark">≡</span><h2>سجل العمليات</h2></div></div><div className="table-scroll"><table><thead><tr><th>العملية</th><th>القسم</th><th>السجل</th><th>المنفذ</th><th>الوقت</th></tr></thead><tbody>{rows.map((row)=><tr key={row.id}><td>{row.action}</td><td>{row.table_name}</td><td dir="ltr">{row.record_id}</td><td dir="ltr">{row.actor_user_id||'—'}</td><td dir="ltr">{new Date(row.occurred_at).toLocaleString('ar-IQ')}</td></tr>)}{!rows.length&&<tr><td colSpan="5" className="empty">لا توجد عمليات مسجلة.</td></tr>}</tbody></table></div></section></div>}

function Trainees({ role, data, trainees, onAdd, onEdit, onDetails, onDelete, onAssign }) { return <div className="content"><section className="panel"><div className="section-heading"><div><span className="accent-mark">♟</span><h2>إدارة المتدربين</h2></div>{role==='admin'&&<button className="btn primary" onClick={onAdd}>＋ إضافة متدرب</button>}</div><div className="table-scroll"><table><thead><tr><th>الاسم الكامل</th><th>الهاتف</th><th>العمر</th><th>الوزن</th><th>الطول</th><th>الكورس</th><th>الاشتراك</th><th>إجراءات</th></tr></thead><tbody>{trainees.map((t) => {const a=data.assignments.find((i)=>i.trainee_id===t.id); const s=data.subscriptions.filter((i)=>i.trainee_id===t.id).sort((x,y)=>y.expires_at.localeCompare(x.expires_at))[0]; return <tr key={t.id}><td className="name-cell"><span className="avatar">{t.full_name.slice(0,1)}</span>{t.full_name}</td><td dir="ltr">{t.phone}</td><td>{t.age}</td><td>{t.weight} كغم</td><td>{t.height} سم</td><td>{data.courses.find((c)=>c.id===a?.course_id)?.name||'—'}</td><td><span className={s?.expires_at>=today()?'pill':'pill muted'}>{s ? s.expires_at>=today()?'نشط':'منتهي':'—'}</span></td><td className="actions"><button title="عرض" className="icon-btn" onClick={()=>onDetails(t)}>◉</button>{role==='coach'&&<button title="تعيين كورس" className="icon-btn" onClick={()=>onAssign(t)}>▣</button>}{role==='admin'&&<><button title="تعديل" className="icon-btn" onClick={()=>onEdit(t)}>✎</button><button title="تعيين كورس" className="icon-btn" onClick={()=>onAssign(t)}>▣</button><button title="حذف" className="icon-btn danger-text" onClick={()=>onDelete(t)}>⌫</button></>}</td></tr>})}{!trainees.length&&<tr><td colSpan="8" className="empty">لا توجد نتائج مطابقة.</td></tr>}</tbody></table></div></section></div> }

function Courses({ role, data, onAdd, onEdit, onArchive, onExercises, onSaveDay, onSaveMuscles, onMoveDay, busy }) { const [showArchived,setShowArchived]=useState(false);return <div className="content"><div className="section-heading page-heading"><div><span className="accent-mark">Ⅱ</span><div><h2>الكورسات التدريبية</h2><small>أيام مرنة وبرامج محفوظة كنسخ تاريخية</small></div></div><div className="actions"><button className="btn ghost" onClick={()=>setShowArchived(v=>!v)}>{showArchived?"عرض الكورسات النشطة":"عرض المؤرشفة"}</button>{!showArchived&&<button className="btn primary" onClick={onAdd}>＋ إنشاء كورس جديد</button>}</div></div><div className="cards-grid">{data.courses.filter((c)=>Boolean(c.archived_at)===showArchived).map((c)=>{const days=data.days.filter((d)=>d.course_id===c.id).sort((a,b)=>a.day_number-b.day_number);const versions=data.versions.filter(v=>v.course_id===c.id).sort((a,b)=>b.version_number-a.version_number);return <article className="panel course-card" key={c.id}><div className="course-card-top"><span className="course-glyph">▣</span><div className="actions"><button className="icon-btn" onClick={()=>onEdit(c)} title="تعديل الكورس">✎</button>{role==='admin'&&<button className="icon-btn danger-text" onClick={()=>onArchive(c)} title={c.archived_at?"استعادة الكورس":"أرشفة الكورس"}>{c.archived_at?"↶":"▣"}</button>}</div></div><h3>{c.name}</h3><p>{c.description||'لا يوجد وصف للكورس.'}</p><small>الكابتن: {data.staff.find((s)=>s.user_id===c.coach_user_id)?.display_name||c.coach_name||'غير محدد'}</small><div className="day-editor-list">{days.map((d,i)=>{const muscleNames=data.dayMuscles.filter(x=>x.course_day_id===d.id).map(x=>data.tags.find(tag=>tag.id===x.tag_id)?.name).filter(Boolean);return <div className="day-editor-row" key={d.id}><div><button className="day-name-button" onClick={()=>{const name=prompt('اسم اليوم التدريبي:',d.name);if(name&&name.trim()!==d.name)onSaveDay(d,{name:name.trim()});}}>{d.name} <small>✎</small></button><small className="day-muscles">{muscleNames.join(' · ')||'لم تحدد العضلات'}</small><button className="text-link" onClick={()=>{const names=prompt('اكتب العضلات التي يستهدفها هذا اليوم، وافصل بينها بفاصلة:',muscleNames.join('، '));if(names!==null)onSaveMuscles(d,names);}}>تعديل العضلات</button></div><div className="actions"><button className="icon-btn" disabled={i===0||busy} onClick={()=>onMoveDay(d,-1)} title="تقديم اليوم">↑</button><button className="icon-btn" disabled={i===days.length-1||busy} onClick={()=>onMoveDay(d,1)} title="تأخير اليوم">↓</button></div></div>})}</div><details className="version-history"><summary>النسخ السابقة ({versions.length})</summary><div>{versions.map(v=><span key={v.id}>نسخة {v.version_number} · {dateLabel(v.created_at)}</span>)}</div></details><button className="btn outline full" onClick={()=>onExercises(c)}>فتح محرر البرنامج ←</button></article>})}{!data.courses.length&&<section className="panel empty-state"><span className="course-glyph">Ⅱ</span><h3>ابدأ بإنشاء أول كورس</h3><p>اختر عدد أيام التدريب الذي يناسب البرنامج.</p><button className="btn primary" onClick={onAdd}>إنشاء كورس</button></section>}</div></div> }

function Exercises({ data, courseId, setCourse, dayId, setDay, onAdd, onEdit, onDelete, onMove, onReorder, busy }) { const course=data.courses.find((c)=>c.id===courseId); const days=data.days.filter((d)=>d.course_id===courseId).sort((a,b)=>a.day_number-b.day_number); const selected=days.find((d)=>d.id===dayId)||days[0]; useEffect(()=>{if(selected&&selected.id!==dayId)setDay(selected.id)},[selected,dayId,setDay]); const list=data.exercises.filter((e)=>e.course_day_id===selected?.id).sort((a,b)=>a.sort_order-b.sort_order); return <div className="content"><section className="panel exercise-toolbar"><label>الكورس<select value={courseId} onChange={(e)=>{setCourse(e.target.value);setDay('')}}><option value="">اختر كورساً</option>{data.courses.filter(c=>!c.archived_at).map((c)=><option key={c.id} value={c.id}>{c.name}</option>)}</select></label>{course&&<><label>يوم التدريب<select value={selected?.id||''} onChange={(e)=>setDay(e.target.value)}>{days.map((d)=><option key={d.id} value={d.id}>{d.name}</option>)}</select></label><button className="btn primary" onClick={onAdd} disabled={!selected}>＋ إضافة تمرين</button></>}</section>{!course?<section className="panel empty-state"><span className="course-glyph">⌁</span><h3>اختر كورساً لعرض التمارين</h3><p>يمكنك إنشاء كورس أولاً من صفحة الكورسات.</p></section>:<section className="panel"><div className="section-heading"><div><span className="accent-mark">⌁</span><div><h2>تمارين {selected?.name||''}</h2><small>{course.name} · {list.length} تمارين</small></div></div><button className="btn primary" onClick={onAdd} disabled={!selected}>＋ إضافة تمرين</button></div><div className="exercise-list">{list.map((e,i)=><article className="exercise-row" key={e.id} data-exercise-id={e.id} draggable={!busy} onDragStart={(event)=>event.dataTransfer.setData("text/plain",e.id)} onDragOver={(event)=>event.preventDefault()} onDrop={(event)=>{event.preventDefault();onReorder(event.dataTransfer.getData("text/plain"),e.id)}}><span className="order">{String(i+1).padStart(2,'0')}</span><div className="exercise-thumb">{e.image_path?<SignedImage path={e.image_path} bucket={e.image_bucket||'exercise-media'}/>:<span>⌁</span>}</div><div className="exercise-info"><b>{e.name}</b><small>{(e.sets_reps?.length?e.sets_reps:String(e.repetitions||'').split(/[،,]/)).map((value,index)=>`ج${index+1}: ${value}`).join(' · ')}</small>{e.notes&&<small>{e.notes}</small>}</div><span className="video-ready">▶ فيديو</span><div className="actions"><button className="icon-btn" disabled={i===0||busy} onClick={()=>onMove(e,-1)} title="للأعلى">↑</button><button className="icon-btn" disabled={i===list.length-1||busy} onClick={()=>onMove(e,1)} title="للأسفل">↓</button><button className="icon-btn" onClick={()=>onEdit(e)} title="تعديل">✎</button><button className="icon-btn danger-text" onClick={()=>onDelete(e)} title="حذف">⌫</button><button className="icon-btn" onClick={()=>openVideo(e.video_path,e.video_bucket||'exercise-media')} title="مشاهدة الفيديو">▶</button></div></article>)}{!list.length&&<div className="empty">لا توجد تمارين لهذا اليوم. أضف التمرين الأول.</div>}</div></section>}</div> }
function RoundInputs({initial=[]}) {const [rounds,setRounds]=useState(initial.length?initial:['12']);const update=(index,value)=>setRounds((items)=>items.map((item,i)=>i===index?value:item));return <Field label="التكرارات لكل جولة"><div className="round-input-list">{rounds.map((value,index)=><div className="round-input" key={index}><span>الجولة {index+1}</span><input name="set_repetitions" aria-label={`تكرارات الجولة ${index+1}`} type="number" min="1" max="999" required value={value} onChange={(e)=>update(index,e.target.value)}/><button type="button" className="icon-btn danger-text" disabled={rounds.length===1} onClick={()=>setRounds((items)=>items.filter((_,i)=>i!==index))} aria-label={`حذف الجولة ${index+1}`}>×</button></div>)}<button type="button" className="btn ghost" onClick={()=>setRounds((items)=>[...items,''])}>＋ إضافة جولة</button></div></Field>}
function SignedImage({path,bucket='exercise-media'}) {const [url,setUrl]=useState('');useEffect(()=>{supabase.storage.from(bucket).createSignedUrl(path,300).then(({data})=>setUrl(data?.signedUrl||''))},[path,bucket]);return url?<img src={url} alt="صورة التمرين"/>:<span>⌁</span>}
function SignedVideo({path,bucket='exercise-media'}) {const [url,setUrl]=useState('');useEffect(()=>{let live=true;supabase.storage.from(bucket).createSignedUrl(path,300).then(({data})=>{if(live)setUrl(data?.signedUrl||'')});return()=>{live=false}},[path,bucket]);return url?<video className="video-preview" controls src={url}/>:<div className="empty">جارٍ تحميل معاينة الفيديو...</div>}
async function openVideo(path,bucket='exercise-media') {const {data,error}=await supabase.storage.from(bucket).createSignedUrl(path,300);if(error)toastError(error);else window.open(data.signedUrl,'_blank','noopener,noreferrer')}

function Subscriptions({ data, onAdd, onRenew }) {const todayStr=today();return <div className="content"><section className="panel"><div className="section-heading"><div><span className="accent-mark">▤</span><h2>الاشتراكات</h2></div><button className="btn primary" onClick={onAdd}>＋ اشتراك جديد</button></div><div className="table-scroll"><table><thead><tr><th>المتدرب</th><th>نوع الاشتراك</th><th>تاريخ البدء</th><th>تاريخ الانتهاء</th><th>الحالة</th><th>إجراء</th></tr></thead><tbody>{[...data.subscriptions].sort((a,b)=>b.expires_at.localeCompare(a.expires_at)).map((s)=><tr key={s.id}><td>{data.trainees.find((t)=>t.id===s.trainee_id)?.full_name||'—'}</td><td>{s.plan_type==='weekly'?'أسبوعي':'شهري'}</td><td dir="ltr">{dateLabel(s.start_date)}</td><td dir="ltr">{dateLabel(s.expires_at)}</td><td><span className={s.start_date<=todayStr&&s.expires_at>=todayStr?'pill':'pill muted'}>{s.start_date>todayStr?'لم يبدأ بعد':s.expires_at>=todayStr?'نشط':'منتهي'}</span></td><td><button className="btn ghost" onClick={()=>onRenew(s)}>تجديد</button></td></tr>)}{!data.subscriptions.length&&<tr><td colSpan="6" className="empty">لا توجد اشتراكات مسجلة.</td></tr>}</tbody></table></div></section></div>}
function Settings({email}) {return <div className="content"><section className="panel settings-card"><span className="accent-mark">⚙</span><h2>إعدادات النظام</h2><p>الهوية وإعداد الاتصال.</p><div className="setting-row"><span>اسم النادي</span><b>NASER AL-ESAWY · نصر العيساوي</b></div><div className="setting-row"><span>اسم النظام</span><b>SYSTEMAK GYM</b></div><div className="setting-row"><span>حساب المدير</span><b>{email}</b></div><div className="setting-row"><span>قاعدة البيانات</span><b className="connected">متصل بـ Supabase</b></div><div className="setting-row"><span>تخزين ملفات التمارين</span><b>خاص · روابط مشاهدة مؤقتة</b></div></section></div>}

function Modal({modal,data,onClose,busy,uploadProgress,onSaveTrainee,onSaveCourse,onSaveExercise,onSaveAssignment,onSaveSubscription,onRecordWeight}) {const formRef=React.useRef();const [videoPreview,setVideoPreview]=useState('');useEffect(()=>()=>{if(videoPreview)URL.revokeObjectURL(videoPreview)},[videoPreview]); const titles={trainee:modal.item?'تعديل بيانات المتدرب':'إضافة متدرب جديد',details:'بيانات المتدرب',course:'إنشاء كورس جديد',exercise:modal.item?'تعديل التمرين':'إضافة تمرين جديد',assignment:'تعيين كورس للمتدرب',subscription:modal.item?'تجديد الاشتراك':'إضافة اشتراك'};
  const submit=(e)=>{e.preventDefault();const f=new FormData(e.currentTarget);const get=(n)=>f.get(n)||'';if(modal.type==='trainee')onSaveTrainee({full_name:get('full_name'),phone:get('phone'),age:get('age'),weight:get('weight'),height:get('height'),member_pin:get('member_pin'),coach_user_id:get('coach_user_id'),course_id:get('course_id'),program_start:get('program_start'),plan_type:get('plan_type'),membership_start:get('membership_start'),membership_end:get('membership_end')},modal.item);if(modal.type==='course')onSaveCourse({name:get('name'),description:get('description'),coach_name:get('coach_name'),coach_user_id:get('coach_user_id'),training_days:get('training_days')},modal.item);if(modal.type==='assignment')onSaveAssignment({trainee_id:get('trainee_id'),course_id:get('course_id'),start_date:get('start_date')},modal.assignment);if(modal.type==='subscription')onSaveSubscription({trainee_id:get('trainee_id'),plan_type:get('plan_type'),start_date:get('start_date'),expires_at:get('expires_at')},modal.item);if(modal.type==='exercise'){const video=f.get('video');const image=f.get('image');onSaveExercise({name:get('name'),sets_reps:f.getAll('set_repetitions'),notes:get('notes'),video:video?.size?video:null,image:image?.size?image:null},modal.item);}};
  const defaults=modal.item||{};
  const renewalStart=modal.item?.expires_at&&modal.item.expires_at>=today()?new Date(`${modal.item.expires_at}T12:00:00`).setDate(new Date(`${modal.item.expires_at}T12:00:00`).getDate()+1):today();
  const renewalStartText=typeof renewalStart==='string'?renewalStart:new Date(renewalStart).toISOString().slice(0,10);
  const subscriptionStart=modal.item?renewalStartText:today();
  const subscriptionPlan=defaults.plan_type||'monthly';
  const subscriptionEnd=addPlanPeriod(subscriptionStart,subscriptionPlan);
  return <div className="modal-backdrop" onMouseDown={(e)=>e.target===e.currentTarget&&onClose()}><section className="modal"><div className="modal-head"><h2>{titles[modal.type]}</h2><button className="icon-btn" onClick={onClose}>×</button></div>{modal.type==='details'?<div className="details-body"><div className="detail-avatar">{modal.item.full_name.slice(0,1)}</div><h3>{modal.item.full_name}</h3><p dir="ltr">{modal.item.phone}</p><div className="detail-grid"><div><small>العمر</small><b>{modal.item.age} سنة</b></div><div><small>الوزن</small><b>{modal.item.weight} كغم</b></div><div><small>الطول</small><b>{modal.item.height} سم</b></div><div><small>الكورس</small><b>{data.courses.find((c)=>c.id===data.assignments.find((a)=>a.trainee_id===modal.item.id)?.course_id)?.name||'غير معيّن'}</b></div><div><small>الاشتراك</small><b>{data.subscriptions.filter((s)=>s.trainee_id===modal.item.id).sort((a,b)=>b.expires_at.localeCompare(a.expires_at))[0]?.expires_at||'غير مشترك'}</b></div></div><div className="weight-history-admin"><b>سجل البرامج</b>{data.programHistory.filter(h=>h.trainee_id===modal.item.id).map(h=><div key={h.id}><span>{data.courses.find(c=>c.id===h.course_id)?.name||'برنامج سابق'} · {dateLabel(h.start_date)}</span><strong>نسخة {data.versions.find(v=>v.id===h.course_version_id)?.version_number||'—'}</strong></div>)}{!data.programHistory.some(h=>h.trainee_id===modal.item.id)&&<small className="hint">لا يوجد سجل برامج قبل تطبيق الترحيل السادس.</small>}</div><div className="weight-history-admin"><b>سجل الوزن</b><WeightChart entries={data.weightHistory.filter(h=>h.trainee_id===modal.item.id)}/>{data.weightHistory.filter(h=>h.trainee_id===modal.item.id).slice(0,8).map(h=><div key={h.id}><span>{dateLabel(h.recorded_at.slice(0,10))}</span><strong>{h.weight} كغم</strong></div>)}{!data.weightHistory.some(h=>h.trainee_id===modal.item.id)&&<small className="hint">سيظهر السجل بعد تطبيق ترحيل سجل الأوزان.</small>}</div><button className="btn ghost full" onClick={()=>onRecordWeight(modal.item)}>＋ تسجيل وزن جديد</button><button className="btn ghost full" onClick={onClose}>إغلاق</button></div>:<form className="modal-form" onSubmit={submit} ref={formRef}>
    {modal.type==='trainee'&&<><Field label="الاسم الكامل"><input name="full_name" required defaultValue={defaults.full_name||''} placeholder="مثال: أحمد محمد"/></Field><Field label="رقم الهاتف"><input name="phone" required dir="ltr" defaultValue={defaults.phone||''} placeholder="07xxxxxxxxx"/></Field><Field label={modal.item?'رمز دخول جديد (اختياري)':'رمز دخول المتدرب (4 أرقام)'}><input name="member_pin" type="password" inputMode="numeric" autoComplete="new-password" required={!modal.item} minLength="4" maxLength="4" pattern="[0-9]{4}" placeholder={modal.item?'اتركه فارغاً للإبقاء على الرمز الحالي':'أدخله وسلّمه للمتدرب مباشرة'} onChange={(e)=>{e.target.value=e.target.value.replace(/\D/g,'').slice(0,4)}}/><small className="hint">لا يُحفظ الرمز في سجل المتدرب؛ يُضبط في Supabase Auth.</small></Field><div className="fields-3"><Field label="العمر"><input name="age" required type="number" min="1" max="110" defaultValue={defaults.age||''}/></Field><Field label="الوزن (كغم)"><input name="weight" required type="number" min="1" step="0.1" defaultValue={defaults.weight||''}/></Field><Field label="الطول (سم)"><input name="height" required type="number" min="1" step="0.1" defaultValue={defaults.height||''}/></Field></div>{!modal.item&&<><div className="onboarding-heading">الربط الأولي <small>اختياري ويمكن إكماله لاحقاً</small></div><Field label="الكابتن المسؤول"><select name="coach_user_id" defaultValue=""><option value="">غير معيّن</option>{data.staff.filter(s=>s.role==='coach').map(s=><option key={s.user_id} value={s.user_id}>{s.display_name||s.user_id}</option>)}</select></Field><Field label="الكورس التدريبي"><select name="course_id" defaultValue=""><option value="">بدون كورس حالياً</option>{data.courses.filter(c=>!c.archived_at).map(c=><option key={c.id} value={c.id}>{c.name}</option>)}</select></Field><Field label="بداية البرنامج"><input name="program_start" type="date" defaultValue={today()}/></Field><Field label="نوع الاشتراك (اختياري)"><select name="plan_type" defaultValue="" onChange={(e)=>{const start=e.currentTarget.form.elements.membership_start.value;if(e.target.value&&start)e.currentTarget.form.elements.membership_end.value=addPlanPeriod(start,e.target.value)}}><option value="">بدون اشتراك الآن</option><option value="weekly">أسبوعي</option><option value="monthly">شهري</option></select></Field><div className="fields-2"><Field label="بداية الاشتراك"><input name="membership_start" type="date" defaultValue={today()} onChange={(e)=>{const type=e.currentTarget.form.elements.plan_type.value;if(type)e.currentTarget.form.elements.membership_end.value=addPlanPeriod(e.target.value,type)}}/></Field><Field label="نهاية الاشتراك"><input name="membership_end" type="date" defaultValue=""/></Field></div><small className="hint">عند اختيار نوع الاشتراك، تُحسب مدة أسبوع أو شهر من تاريخ البداية. يمكنك تعديل تاريخ الانتهاء.</small></>}</>}
    {modal.type==='course'&&<><Field label="اسم الكورس"><input name="name" required defaultValue={defaults.name||''} placeholder="مثال: كورس اللياقة المتقدمة"/></Field><Field label="وصف الكورس"><textarea name="description" rows="3" defaultValue={defaults.description||''} placeholder="وصف موجز للكورس"/></Field><Field label="اسم الكابتن"><input name="coach_name" defaultValue={defaults.coach_name||''} placeholder="اسم الكابتن"/></Field><Field label="حساب الكابتن المسؤول"><select name="coach_user_id" defaultValue={defaults.coach_user_id||''}><option value="">غير مسند إلى حساب كابتن</option>{data.staff.filter((s)=>s.role==='coach').map((s)=><option key={s.user_id} value={s.user_id}>{s.display_name||s.user_id}</option>)}</select></Field><Field label="عدد أيام التدريب"><input name="training_days" type="number" min="1" max="30" defaultValue={defaults.training_days||3} required/></Field><p className="hint">تُنشأ الأيام تلقائياً حسب العدد الذي تختاره، دون إنشاء أيام راحة. عند تعديل العدد تُحفظ نسخة جديدة من البرنامج.</p></>}
    {modal.type==='exercise'&&<><Field label="اسم التمرين"><input name="name" required defaultValue={defaults.name||''} placeholder="مثال: ضغط الصدر بالدمبل"/></Field><RoundInputs key={modal.item?.id||'new'} initial={modal.item?.sets_reps?.length?modal.item.sets_reps:String(modal.item?.repetitions||'').split(/[،,]/).map(x=>x.trim()).filter(Boolean)}/><Field label={`فيديو التمرين ${modal.item?'(اختياري عند الاحتفاظ بالحالي)':'(مطلوب)'}`}><input name="video" type="file" accept="video/mp4,video/quicktime,video/webm,video/x-msvideo" required={!modal.item} onChange={(e)=>{const file=e.target.files?.[0];if(file){if(!['video/mp4','video/quicktime','video/webm','video/x-msvideo'].includes(file.type)){e.target.value='';alert('صيغة الفيديو غير مدعومة. استخدم MP4 أو MOV أو WebM أو AVI.');return;}if(file.size>200*1024*1024){e.target.value='';alert('الحد الأقصى لحجم الفيديو 200 ميغابايت');return;}setVideoPreview(URL.createObjectURL(file));}}}/><small className="hint">MP4 أو MOV أو WebM أو AVI · الحد الأقصى 200 ميغابايت</small></Field>{videoPreview?<video className="video-preview" controls src={videoPreview}/>:modal.item?.video_path&&<SignedVideo path={modal.item.video_path} bucket={modal.item.video_bucket||'exercise-media'}/ >}{uploadProgress!==null&&<><div className="progress" role="progressbar" aria-valuenow={uploadProgress} aria-valuemin="0" aria-valuemax="100"><span style={{width:`${uploadProgress}%`}}/></div><small className="hint">جارٍ رفع الملف: {uploadProgress}%</small></>}<Field label="صورة توضيحية (اختياري)"><input name="image" type="file" accept="image/jpeg,image/png,image/webp" onChange={(e)=>{const file=e.target.files?.[0];if(file){if(!['image/jpeg','image/png','image/webp'].includes(file.type)){e.target.value='';alert('صيغة الصورة غير مدعومة. استخدم JPG أو PNG أو WebP.');return;}if(file.size>10*1024*1024){e.target.value='';alert('الحد الأقصى لحجم الصورة 10 ميغابايت');return;}}}}/></Field><Field label="ملاحظات التمرين (اختياري)"><textarea name="notes" rows="2" defaultValue={defaults.notes||''} placeholder="ملاحظات تساعد على أداء التمرين"/></Field></>}
    {modal.type==='assignment'&&<><Field label="المتدرب"><select name="trainee_id" required defaultValue={modal.item?.id||''}><option value="">اختر متدرباً</option>{data.trainees.map((t)=><option key={t.id} value={t.id}>{t.full_name} · {t.phone}</option>)}</select></Field><Field label="الكورس"><select name="course_id" required defaultValue={modal.assignment?.course_id||''}><option value="">اختر كورساً</option>{data.courses.filter(c=>!c.archived_at).map((c)=><option key={c.id} value={c.id}>{c.name}</option>)}</select></Field><Field label="تاريخ البدء"><input name="start_date" type="date" required defaultValue={modal.assignment?.start_date||today()}/></Field></>}
    {modal.type==='subscription'&&<><Field label="المتدرب"><select name="trainee_id" required defaultValue={modal.item?.trainee_id||''}><option value="">اختر متدرباً</option>{data.trainees.map((t)=><option key={t.id} value={t.id}>{t.full_name}</option>)}</select></Field><Field label="نوع الاشتراك"><select name="plan_type" defaultValue={subscriptionPlan} onChange={(e)=>{if(formRef.current?.elements.start_date)formRef.current.elements.expires_at.value=addPlanPeriod(formRef.current.elements.start_date.value,e.target.value);}}><option value="weekly">أسبوعي</option><option value="monthly">شهري</option></select></Field><div className="fields-2"><Field label="تاريخ البدء"><input name="start_date" type="date" required defaultValue={subscriptionStart} onChange={(e)=>{if(formRef.current?.elements.plan_type)formRef.current.elements.expires_at.value=addPlanPeriod(e.target.value,formRef.current.elements.plan_type.value);}}/></Field><Field label="تاريخ الانتهاء"><input name="expires_at" type="date" required defaultValue={subscriptionEnd}/></Field></div><p className="hint">التجديد يضيف سجلاً جديداً ولا يستبدل سجل الاشتراك السابق.</p></>}
    <div className="modal-actions"><button type="button" className="btn ghost" onClick={onClose}>إلغاء</button><button className="btn primary" disabled={busy}>{busy?'جارٍ الحفظ...':'حفظ'}</button></div></form>}</section></div>
}
function Field({label,children}) {return <label className="field"><span>{label}</span>{children}</label>}
function WeightChart({entries}){const points=[...entries].sort((a,b)=>a.recorded_at.localeCompare(b.recorded_at));if(points.length<2)return null;const vals=points.map(p=>Number(p.weight));const min=Math.min(...vals),max=Math.max(...vals);const span=Math.max(1,max-min);const xy=points.map((point,i)=>`${i/(points.length-1)*260},${78-(Number(point.weight)-min)/span*65}`).join(' ');return <svg className="weight-chart" viewBox="0 0 260 90" role="img" aria-label="رسم تغير الوزن عبر الوقت"><polyline points={xy} fill="none" stroke="#f22d33" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round"/>{points.map((point,i)=><circle key={point.id} cx={i/(points.length-1)*260} cy={78-(Number(point.weight)-min)/span*65} r="3.5" fill="#ff5a5f"/>)}<text x="3" y="12" fill="#aaa" fontSize="10">{max} كغم</text><text x="3" y="88" fill="#aaa" fontSize="10">{min} كغم</text></svg>}

createRoot(document.getElementById('root')).render(window.location.pathname.startsWith('/member') ? <MemberApp/> : <App/>);
