import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { supabase } from './supabase.js';
import './member.css';

const dayNames = ['الأول', 'الثاني', 'الثالث', 'الرابع', 'الخامس', 'السادس', 'السابع', 'الثامن', 'التاسع', 'العاشر'];
const msg = (text) => text || 'تعذر إكمال العملية. حاول مرة أخرى.';
const dateText = (date) => date ? new Date(`${date}T12:00:00`).toLocaleDateString('ar-IQ', { year: 'numeric', month: 'long', day: 'numeric' }) : '—';

export function normalizeIraqiPhone(value) {
  let digits = String(value || '').replace(/\D/g, '');
  if (!digits) return '';
  if (digits.startsWith('00964')) digits = digits.slice(2);
  if (digits.startsWith('964')) return `+${digits}`;
  if (digits.startsWith('0')) return `+964${digits.slice(1)}`;
  if (digits.startsWith('7')) return `+964${digits}`;
  return `+${digits}`;
}

export function MemberApp() {
  const [session, setSession] = useState(null);
  const [authReady, setAuthReady] = useState(false);
  const [phoneInput, setPhoneInput] = useState('');
  const [pin, setPin] = useState('');
  const [captchaToken, setCaptchaToken] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const [page, setPage] = useState('home');
  const [member, setMember] = useState(null);
  const [course, setCourse] = useState(null);
  const [days, setDays] = useState([]);
  const [exercises, setExercises] = useState([]);
  const [assignments, setAssignments] = useState([]);
  const [subscriptions, setSubscriptions] = useState([]);
  const [weightHistory, setWeightHistory] = useState([]);
  const [coachName, setCoachName] = useState('');
  const [selectedDay, setSelectedDay] = useState(null);
  const [selectedExercise, setSelectedExercise] = useState(0);
  const [refreshing, setRefreshing] = useState(false);

  useEffect(() => {
    if (!supabase) { setAuthReady(true); return; }
    let mounted = true;
    supabase.auth.getSession().then(({ data: { session: current } }) => { if (mounted) { setSession(current); setAuthReady(true); } });
    const { data: { subscription } } = supabase.auth.onAuthStateChange((_event, current) => setSession(current));
    return () => { mounted = false; subscription.unsubscribe(); };
  }, []);

  const loadMember = useCallback(async (silent = false) => {
    if (!supabase || !session) return;
    if (!silent) setRefreshing(true);
    const staffResult = await supabase.from('gym_staff').select('role').eq('user_id', session.user.id).maybeSingle();
    if (staffResult.data) { setMember(null); setError('حساب الموظف لا يستخدم واجهة المتدرب.'); setRefreshing(false); return; }
    const profileResult = await supabase.from('trainees').select('id,full_name,age,weight,height').maybeSingle();
    if (profileResult.error || !profileResult.data) {
      setMember(null); setCourse(null); setDays([]); setExercises([]); setAssignments([]); setSubscriptions([]);
      setError(profileResult.error?.message || 'لم يتم ربط الحساب بسجل متدرب. تواصل مع إدارة النادي.');
      setRefreshing(false); return;
    }
    const person = profileResult.data;
    const [assignmentResult, subscriptionResult, weightResult, coachResult] = await Promise.all([
      supabase.from('course_assignments').select('id,course_id,course_version_id,start_date').eq('trainee_id', person.id).maybeSingle(),
      supabase.from('subscriptions').select('id,plan_type,start_date,expires_at').eq('trainee_id', person.id).order('start_date', { ascending: false }),
      supabase.from('trainee_weight_history').select('id,weight,recorded_at').eq('trainee_id', person.id).order('recorded_at', { ascending: false }).limit(12),
      supabase.rpc('member_coach_name'),
    ]);
    if (assignmentResult.error) { setError(msg(assignmentResult.error.message)); setRefreshing(false); return; }
    if (weightResult.error) { setError(msg(weightResult.error.message)); setRefreshing(false); return; }
    const assigned = assignmentResult.data;
    let program = null; let trainingDays = []; let allExercises = [];
    if (assigned) {
      if (assigned.course_version_id) {
        const versionResult = await supabase.from('course_versions').select('snapshot').eq('id', assigned.course_version_id).maybeSingle();
        if (versionResult.error) { setError(msg(versionResult.error.message)); setRefreshing(false); return; }
        if (versionResult.data?.snapshot) {
          program = versionResult.data.snapshot.course || null;
          trainingDays = (versionResult.data.snapshot.days || []).map((entry) => ({ ...entry.day, muscle_names: entry.muscles || [] }));
          allExercises = (versionResult.data.snapshot.days || []).flatMap((entry) => entry.exercises || []);
        }
      }
      if (!assigned.course_version_id || !program) {
      const courseResult = await supabase.from('courses').select('id,name,description,training_days').eq('id', assigned.course_id).maybeSingle();
      if (courseResult.error) { setError(msg(courseResult.error.message)); setRefreshing(false); return; }
      program = courseResult.data;
      if (program) {
        const dayResult = await supabase.from('course_days').select('id,course_id,day_number,name').eq('course_id', program.id).order('day_number', { ascending: true });
        if (dayResult.error) { setError(msg(dayResult.error.message)); setRefreshing(false); return; }
        trainingDays = dayResult.data || [];
        if (trainingDays.length) {
        const exerciseResult = await supabase.from('exercises').select('id,course_day_id,name,repetitions,sets_reps,image_path,image_bucket,video_path,video_bucket,notes,sort_order').in('course_day_id', trainingDays.map((d) => d.id)).order('sort_order', { ascending: true });
          if (exerciseResult.error) { setError(msg(exerciseResult.error.message)); setRefreshing(false); return; }
        allExercises = exerciseResult.data || [];
        const muscleResult = await supabase.from('course_day_muscles').select('course_day_id,tag_id,exercise_tags(name)').in('course_day_id', trainingDays.map((d) => d.id));
        if (!muscleResult.error) trainingDays = trainingDays.map((day) => ({ ...day, muscle_names: muscleResult.data.filter((row) => row.course_day_id === day.id).map((row) => row.exercise_tags?.name).filter(Boolean) }));
        }
      }
      }
    }
    setMember(person); setCoachName(coachResult.data||''); setCourse(program); setDays(trainingDays); setExercises(allExercises);
    setAssignments(assigned ? [assigned] : []); setSubscriptions(subscriptionResult.data || []); setWeightHistory(weightResult.data||[]);
    setError(''); setRefreshing(false);
  }, [session]);

  useEffect(() => {
    if (!session || !supabase) return;
    let alive = true;
    const update = () => { if (alive) loadMember(true); };
    loadMember();
    const channel = supabase.channel(`member-${session.user.id}`)
      .on('postgres_changes', { event: '*', schema: 'public', table: 'trainees' }, update)
      .on('postgres_changes', { event: '*', schema: 'public', table: 'course_assignments' }, update)
      .on('postgres_changes', { event: '*', schema: 'public', table: 'courses' }, update)
      .on('postgres_changes', { event: '*', schema: 'public', table: 'course_days' }, update)
      .on('postgres_changes', { event: '*', schema: 'public', table: 'exercises' }, update)
      .on('postgres_changes', { event: '*', schema: 'public', table: 'subscriptions' }, update)
      .subscribe((status) => { if (status === 'SUBSCRIBED') update(); });
    return () => { alive = false; supabase.removeChannel(channel); };
  }, [session, loadMember]);

  const sortedDays = useMemo(() => [...days].sort((a, b) => a.day_number - b.day_number), [days]);
  const exercisesFor = useCallback((dayId) => exercises.filter((e) => e.course_day_id === dayId).sort((a, b) => a.sort_order - b.sort_order), [exercises]);
  const currentExercises = selectedDay ? exercisesFor(selectedDay.id) : [];
  const activeSubscription = subscriptions.find((s) => s.start_date <= new Date().toISOString().slice(0, 10) && s.expires_at >= new Date().toISOString().slice(0, 10)) || subscriptions[0];

  const loginWithPin = async (event) => {
    event.preventDefault(); setError('');
    if (!supabase) return;
    const normalized = normalizeIraqiPhone(phoneInput);
    if (normalized.length < 11) { setError('أدخل رقم هاتف صحيحاً.'); return; }
    if (!/^\d{4}$/.test(pin)) { setError('أدخل الرمز السري المكوّن من 4 أرقام.'); return; }
    const captchaSiteKey = import.meta.env.VITE_SUPABASE_CAPTCHA_SITE_KEY;
    if (captchaSiteKey && !captchaToken) { setError('أكمل خطوة التحقق قبل تسجيل الدخول.'); return; }
    setBusy(true);
    const { data, error: loginError } = await supabase.functions.invoke('member-pin-login', { body: { phone: normalized, pin, ...(captchaToken ? { captchaToken } : {}) } });
    setCaptchaToken('');
    setBusy(false);
    if (loginError) {
      const status = loginError.context?.status;
      setError(status === 404 ? 'رقم الهاتف غير مسجل في النظام.' : status === 409 ? 'لم تفعّل الإدارة رمز الدخول لهذا الرقم بعد.' : status === 429 ? 'محاولات كثيرة. انتظر قليلاً ثم أعد المحاولة.' : 'رقم الهاتف أو الرمز السري غير صحيح.');
      return;
    }
    if (!data?.session?.access_token || !data?.session?.refresh_token) { setError('تعذر إنشاء جلسة الدخول. حاول مرة أخرى.'); return; }
    const { error: sessionError } = await supabase.auth.setSession({ access_token: data.session.access_token, refresh_token: data.session.refresh_token });
    if (sessionError) setError('تعذر حفظ جلسة الدخول. حاول مرة أخرى.');
  };

  const logout = async () => { await supabase.auth.signOut(); setSession(null); setMember(null); setPin(''); setPhoneInput(''); setCaptchaToken(''); setPage('home'); setError(''); };

  if (!supabase) return <MemberSetup/>;
  if (!authReady) return <div className="member-loading"><span className="spinner"/> جاري التحقق من الجلسة...</div>;
  if (!session) return <MemberAuth phoneInput={phoneInput} setPhoneInput={setPhoneInput} pin={pin} setPin={setPin} busy={busy} error={error} captchaToken={captchaToken} setCaptchaToken={setCaptchaToken} onLogin={loginWithPin}/>;
  if (!member) return <div className="member-auth" dir="rtl"><div className="member-auth-card"><div className="member-auth-brand"><img src="/systemak-logo.png" alt="SYSTEMAK GYM"/><b>NASER AL-ESAWY</b><span>نصر العيساوي · SYSTEMAK GYM</span></div><h1>{error?'تعذر فتح ملف المتدرب':'جارٍ تحميل ملفك...'}</h1>{error&&<><p>{error}</p><button className="member-button full" onClick={logout}>تسجيل الخروج</button></>}</div></div>;

  const openDay = (day) => { setSelectedDay(day); setPage('day'); };
  const openExercise = (exercise) => { setSelectedExercise(currentExercises.findIndex((e) => e.id === exercise.id)); setPage('exercise'); };
  const home = page === 'home';
  const programPage = page === 'program';
  const accountPage = page === 'account';

  return <div className="member-app" dir="rtl">
    <header className="member-top"><div className="member-brand"><img src="/systemak-logo.png" alt="SYSTEMAK GYM"/><span><b>NASER AL-ESAWY</b><small>نصر العيساوي · SYSTEMAK GYM</small></span></div><button className="member-refresh" onClick={() => loadMember()} aria-label="تحديث">↻</button></header>
    <main className="member-main">
      {refreshing && <div className="member-sync">جارٍ تحديث البرنامج التدريبي...</div>}
      {home && <>
        <section className="member-welcome"><span className="member-kicker">أهلاً بك في SYSTEMAK GYM</span><h1>{member.full_name}</h1><p>برنامجك التدريبي جاهز</p></section>
        <section className="member-vitals"><div><small>العمر</small><b>{member.age} <em>سنة</em></b></div><div><small>الوزن</small><b>{member.weight} <em>كغم</em></b></div><div><small>الكابتن</small><b>{coachName||'—'}</b></div></section>
        {!course ? <section className="member-panel member-empty"><span>Ⅱ</span><h2>لا يوجد كورس تدريبي مخصص لك حالياً.</h2><p>راجع إدارة النادي للحصول على برنامجك التدريبي.</p></section> : <>
          <section className="member-panel member-course"><div className="member-panel-title"><div><span className="red-glyph">Ⅱ</span><div><small>الكورس المخصص لك</small><h2>{course.name}</h2></div></div><button className="text-link" onClick={() => setPage('program')}>عرض البرنامج ←</button></div></section>
          {activeSubscription && <section className="member-meta"><span>بداية الاشتراك</span><b>{dateText(activeSubscription.start_date)}</b></section>}
          <section className="member-day-section"><div className="member-section-heading"><h2>أيام التدريب</h2><button onClick={() => setPage('program')}>البرنامج كاملاً ←</button></div><div className="member-day-grid">{sortedDays.map((day) => <DayCard key={day.id} day={day} count={exercisesFor(day.id).length} onClick={() => openDay(day)}/>)}</div></section>
        </>}
      </>}

      {programPage && <><MemberPageHeading eyebrow="خطة النادي" title="برنامجي التدريبي" back={() => setPage('home')}/>{!course ? <EmptyCourse/> : <><section className="member-panel member-course"><small>الكورس المخصص لك</small><h2>{course.name}</h2>{course.description&&<p>{course.description}</p>}</section><div className="member-day-grid expanded">{sortedDays.map((day)=><DayCard key={day.id} day={day} count={exercisesFor(day.id).length} onClick={()=>openDay(day)}/>)}</div></>}</>}

      {page === 'day' && <><MemberPageHeading eyebrow={course?.name||'البرنامج'} title={selectedDay?.name || 'يوم التدريب'} back={() => setPage('program')}/><p className="member-count">{currentExercises.length} تمارين</p><div className="member-exercise-list">{currentExercises.map((exercise,index)=><ExerciseCard key={exercise.id} exercise={exercise} index={index} onClick={()=>openExercise(exercise)}/>)}{!currentExercises.length&&<section className="member-panel member-empty"><p>لا توجد تمارين لهذا اليوم حتى الآن.</p></section>}</div></>}

      {page === 'exercise' && currentExercises[selectedExercise] && <><MemberPageHeading eyebrow={selectedDay?.name||''} title="تفاصيل التمرين" back={() => setPage('day')}/><MemberExercise exercise={currentExercises[selectedExercise]} index={selectedExercise} total={currentExercises.length} onPrevious={()=>setSelectedExercise((n)=>Math.max(n-1,0))} onNext={()=>setSelectedExercise((n)=>Math.min(n+1,currentExercises.length-1))}/></>}

      {accountPage && <><MemberPageHeading eyebrow="ملفك في النادي" title="حسابي"/><section className="member-panel member-account"><div className="member-avatar">{member.full_name.slice(0,1)}</div><h2>{member.full_name}</h2><div className="member-meta"><span>رقم الهاتف</span><b dir="ltr">{session.user.phone || phone}</b></div><div className="member-meta"><span>العمر · الطول · الوزن</span><b>{member.age} سنة · {member.height||'—'} سم · {member.weight} كغم</b></div><div className="member-meta"><span>الكابتن المسؤول</span><b>{coachName||'—'}</b></div><div className="member-meta"><span>حالة الاشتراك</span><b>{activeSubscription?(activeSubscription.start_date<=new Date().toISOString().slice(0,10)&&activeSubscription.expires_at>=new Date().toISOString().slice(0,10)?'نشط':'لم يبدأ بعد'):'غير مشترك'}</b></div><div className="member-meta"><span>تاريخ بدء الاشتراك</span><b>{dateText(activeSubscription?.start_date)}</b></div><div className="member-meta"><span>الكورس الحالي</span><b>{course?.name || '—'}</b></div>{weightHistory.length>0&&<div className="member-weight-history"><b>سجل الوزن</b>{weightHistory.map((entry)=><div key={entry.id}><span>{dateText(entry.recorded_at.slice(0,10))}</span><strong>{entry.weight} كغم</strong></div>)}</div>}<button className="member-button secondary full" onClick={logout}>تسجيل الخروج</button></section></>}
    </main>
    <nav className="member-bottom" aria-label="التنقل الرئيسي"><button className={home?'selected':''} onClick={()=>setPage('home')}><span>⌂</span>الرئيسية</button><button className={programPage||page==='day'||page==='exercise'?'selected':''} onClick={()=>setPage('program')}><span>Ⅱ</span>برنامجي التدريبي</button><button className={accountPage?'selected':''} onClick={()=>setPage('account')}><span>◉</span>حسابي</button></nav>
  </div>;
}

function MemberAuth({phoneInput,setPhoneInput,pin,setPin,busy,error,captchaToken,setCaptchaToken,onLogin}) {
  return <div className="member-auth" dir="rtl"><div className="member-auth-card"><div className="member-auth-brand"><img src="/systemak-logo.png" alt="SYSTEMAK GYM"/><b>NASER AL-ESAWY</b><span>نصر العيساوي · SYSTEMAK GYM</span></div><h1>دخول المتدرب</h1><p>استخدم رقم الهاتف المسجل لدى النادي والرمز السري المكوّن من 4 أرقام.</p>{error&&<div className="member-error" role="alert">{error}</div>}<form onSubmit={onLogin}><label>رقم الهاتف<input type="tel" inputMode="tel" autoComplete="tel" required value={phoneInput} onChange={(e)=>setPhoneInput(e.target.value)} placeholder="07xxxxxxxxx" dir="ltr"/></label><small className="member-hint">أرقام العراق المحلية أو الدولية</small><label>الرمز السري<input type="password" inputMode="numeric" autoComplete="current-password" required minLength="4" maxLength="4" pattern="[0-9]{4}" value={pin} onChange={(e)=>setPin(e.target.value.replace(/\D/g,'').slice(0,4))} placeholder="••••" dir="ltr"/></label><small className="member-hint">تحصل على الرمز من إدارة النادي.</small><Turnstile onToken={setCaptchaToken}/><button className="member-button full" disabled={busy || (Boolean(import.meta.env.VITE_SUPABASE_CAPTCHA_SITE_KEY) && !captchaToken)}>{busy?'جارٍ تسجيل الدخول...':'تسجيل الدخول'}</button></form><small className="member-privacy-note">الدخول متاح فقط للمتدربين المسجلين والمفعّل رمزهم من الإدارة.</small></div></div>;
}

function Turnstile({onToken}) {
  const siteKey = import.meta.env.VITE_SUPABASE_CAPTCHA_SITE_KEY;
  const mount = useRef(null);
  useEffect(() => {
    if (!siteKey || !mount.current) return;
    let widgetId; let cancelled = false;
    const render = () => { if (!cancelled && window.turnstile && mount.current) widgetId = window.turnstile.render(mount.current, { sitekey: siteKey, callback: onToken, 'expired-callback': () => onToken(''), 'error-callback': () => onToken('') }); };
    if (window.turnstile) render();
    else {
      const script = document.createElement('script'); script.src = 'https://challenges.cloudflare.com/turnstile/v0/api.js?render=explicit'; script.async = true; script.defer = true; script.onload = render; document.head.appendChild(script);
    }
    return () => { cancelled = true; if (widgetId && window.turnstile) window.turnstile.remove(widgetId); };
  }, [siteKey, onToken]);
  return siteKey ? <div className="turnstile-wrap"><div ref={mount}/></div> : null;
}

function DayCard({day,count,onClick}) {const ordinal=dayNames[day.day_number-1]||day.day_number;return <button className="member-day-card" onClick={onClick}><span className="day-index">{String(day.day_number).padStart(2,'0')}</span><span className="day-title">{day.name||`اليوم ${ordinal}`}</span>{day.muscle_names?.length>0&&<span className="day-count">{day.muscle_names.join(' · ')}</span>}<span className="day-count">{count} {count===1?'تمرين':'تمارين'}</span><span className="day-arrow">←</span></button>}
function exerciseRounds(exercise){return exercise.sets_reps?.length?exercise.sets_reps:String(exercise.repetitions||'').split(/[،,]/).map((x)=>x.trim()).filter(Boolean)}
function ExerciseCard({exercise,index,onClick}) {return <button className="member-exercise-card" onClick={onClick}><span className="exercise-num">{String(index+1).padStart(2,'0')}</span><div className="exercise-picture">{exercise.image_path?<MemberImage path={exercise.image_path} bucket={exercise.image_bucket||'exercise-media'}/>:<span>⌁</span>}</div><span className="exercise-card-info"><b>{exercise.name}</b><small>{exerciseRounds(exercise).length} جولات · {exerciseRounds(exercise).join('، ')}</small></span><span className="play-badge">▶</span></button>}
function MemberPageHeading({eyebrow,title,back}) {return <header className="member-page-heading">{back&&<button className="member-back" onClick={back}>←</button>}<div><small>{eyebrow}</small><h1>{title}</h1></div></header>}
function MemberImage({path,bucket='exercise-media'}) {const [src,setSrc]=useState('');useEffect(()=>{let active=true;supabase.storage.from(bucket).createSignedUrl(path,300).then(({data})=>{if(active)setSrc(data?.signedUrl||'')});return()=>{active=false}},[path,bucket]);return src?<img src={src} alt="صورة توضيحية للتمرين" loading="lazy"/>:<span>⌁</span>}
function MemberExercise({exercise,index,total,onPrevious,onNext}) {const [url,setUrl]=useState('');const [error,setError]=useState('');const bucket=exercise.video_bucket||'exercise-media';useEffect(()=>{let active=true;setUrl('');setError('');supabase.storage.from(bucket).createSignedUrl(exercise.video_path,3600).then(({data,error:storageError})=>{if(!active)return;if(storageError)setError('تعذر تحميل الفيديو. أعد المحاولة لاحقاً.');else setUrl(data?.signedUrl||'')});return()=>{active=false}},[exercise.id,exercise.video_path,bucket]);const rounds=exerciseRounds(exercise);return <article className="member-panel member-video-page"><span className="member-exercise-position">التمرين {index+1} من {total}</span><h2>{exercise.name}</h2><div className="member-rounds">{rounds.map((value,i)=><div key={i}><small>الجولة {i+1}</small><b>{value} تكرارات</b></div>)}</div><div className="member-video-frame">{url?<video src={url} controls playsInline preload="metadata" controlsList="nodownload" aria-label={`فيديو تمرين ${exercise.name}`}/>:<div className="video-loading">{error||'جارٍ تجهيز الفيديو...'}</div>}</div>{exercise.notes&&<div className="coach-note"><small>ملاحظات المدرب</small><p>{exercise.notes}</p></div>}<div className="exercise-nav"><button className="member-button secondary" disabled={index===0} onClick={onPrevious}>التمرين السابق</button><button className="member-button" disabled={index===total-1} onClick={onNext}>التمرين التالي</button></div></article>}
function EmptyCourse() {return <section className="member-panel member-empty"><span>Ⅱ</span><h2>لا يوجد كورس تدريبي مخصص لك حالياً.</h2><p>سيظهر برنامجك هنا بعد تعيينه من إدارة النادي.</p></section>}
function MemberSetup() {return <div className="member-auth" dir="rtl"><div className="member-auth-card"><div className="member-auth-brand"><img src="/systemak-logo.png" alt="SYSTEMAK GYM"/><b>NASER AL-ESAWY</b><span>نصر العيساوي · SYSTEMAK GYM</span></div><h1>إعداد التطبيق</h1><p>أضف إعدادات Supabase إلى ملف .env، ثم أعد تشغيل الموقع.</p></div></div>}
