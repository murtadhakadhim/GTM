# SYSTEMAK GYM — Administration Dashboard

Arabic, right-to-left gym administration dashboard for NASER AL-ESAWY.

## Run

1. Install Node.js 20.19+ or 22.12+.
2. Run `npm ci`.
3. Copy `.env.example` to `.env` and set the Supabase project URL and publishable (anon) key.
4. Run all three SQL files in `supabase/migrations/` in numerical order in the Supabase SQL editor.
5. Set a private random `MEMBER_PIN_PEPPER` secret and deploy `member-pin-login` and `set-member-pin` as described in `SUPABASE_SETUP.md`. Member sign-in uses a registered Iraqi phone plus a four-digit admin-set PIN; it does not send SMS/OTP. Optional Turnstile can be enabled in Supabase Auth and the app using `VITE_SUPABASE_CAPTCHA_SITE_KEY`.
7. Create the administrator in Supabase Authentication, then add the Auth user to `public.gym_staff` with role `admin` using the example statement at the end of migration `002_member_app_security.sql`.
8. Run `npm run dev`. The admin dashboard is at `/`; the member website is at `/member`.

The dashboard and member website use the same Supabase Auth, Postgres records, and private Storage buckets. The PIN function links Auth users only to an existing trainee row with a unique registered phone; RLS limits each member to their linked profile, assigned course, subscriptions, and media for that assigned course. Existing files remain in `exercise-media`; new videos and images use the separate private `exercise-videos` and `exercise-images` buckets. The connection panel is shown until credentials exist; the app does not seed fake records. Exercise playback uses short-lived signed URLs. PIN setup is admin-managed and does not include self-service recovery.

See [SUPABASE_SETUP.md](SUPABASE_SETUP.md), [PRODUCTION_DEPLOYMENT.md](PRODUCTION_DEPLOYMENT.md), and [MEMBER_APP_INTEGRATION_REPORT.md](MEMBER_APP_INTEGRATION_REPORT.md) before production. The generated ZIP contains the verified build output and excludes local dependencies and secrets.
